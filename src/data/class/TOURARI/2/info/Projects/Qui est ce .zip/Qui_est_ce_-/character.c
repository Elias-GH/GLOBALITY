#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "structure.h"
#include "character.h"
#include "liste.h"

#define blue  "\x1B[36m"
#define red   "\x1B[31m"
#define green "\x1B[32m"
#define white "\x1B[37m"

void clearScreen() {		// Efface le contenu du terminal pour un meilleur affichage
	printf("%c[2J", 0x1B);
	printf("%c[%d;%dH", 0x1B, 1, 1);
}

persoCharacteristic createCharacter(PtListe allPerso){		// création d'un personnage
    int isNotTrue = 1;		// variable pour déterminer les premières caractéristiques entre les hommes et les femmes
    char sexe[2][20]      = {"homme" , "femme"};
    char name[20][20]     = {"Jérémy", "Felix"   , "Sofiane", "Thomas", "Paul", "Jean-Marc","Jason", "Baptiste", "Julien", "Nicolas", "Jeannine", "Martine", "Aurore", "Lise", "Manon", "Sylvie", "Alexia", "Léa", "Camille", "Chloe"};
    char formes[3][20]    = {"carré" , "ovale"   , "rond"};
    char longHair[3][20]  = {"chauve", "court"   , "long"};
    char colorHair[5][20] = {"noir"  , "brun"    , "blond"  , "roux"  , "gris"};
    char eyes[4][20]      = {"noirs" , "marrons" , "bleus"  , "verts"};
    char beard[3][20]     = {"aucun" , "courte"  , "longue"};
    char mustache[3][20]  = {"aucun" , "courte"  , "longue"};
    char accessory[3][20] = {"aucun" , "lunettes", "chapeau"};

    persoCharacteristic perso;
    while (isNotTrue) {		// Tant que les premières caractéristiques ne sont pas correctement déterminer, on continue de bouclé
        perso.sexe = strdup(sexe[rand()%2]);	// selection du sexe
        if (!strcmp(perso.sexe, "homme")) {		// Si homme alors barbe et moustache autorisé
            perso.name = strdup(name[rand()%10]);	// Les 10 premiers noms de la lise sont des noms masculins
            perso.beard     = strdup(beard[rand()%3]);
            perso.mustache  = strdup(mustache[rand()%3]);
            if (!alreadyExist(allPerso, perso)) break;	// Si le nom du personnage n'existe pas déjà alors il est validé
        } else {
            perso.name = strdup(name[rand()%10 + 10]);	// Les 10 suivants sont féminins
            perso.beard     = strdup(beard[0]);			// barbe non autorisé
            perso.mustache  = strdup(mustache[0]);		// mustache none autorisé
            if (!alreadyExist(allPerso, perso)) break;	// Si le nom du personnage n'existe pas déjà alors il est validé
        }
    }
	// Selection des autres caractéristiques
    perso.formes    = strdup(formes[rand()%3]);
    perso.longHair  = strdup(longHair[rand()%3]);
    perso.colorHair = strdup(colorHair[rand()%5]);
    perso.eyes      = strdup(eyes[rand()%4]);
    perso.accessory = strdup(accessory[rand()%3]);

    return perso;		// retourne le personnage final
}

persoCharacteristic copyCharacter(persoCharacteristic perso) {	// copie un personnage entier
    persoCharacteristic cpyPerso;
    cpyPerso.sexe      = strdup(perso.sexe);
    cpyPerso.name      = strdup(perso.name);
    cpyPerso.formes    = strdup(perso.formes);
    cpyPerso.longHair  = strdup(perso.longHair);
    cpyPerso.colorHair = strdup(perso.colorHair);
    cpyPerso.eyes      = strdup(perso.eyes);
    cpyPerso.beard     = strdup(perso.beard);
    cpyPerso.mustache  = strdup(perso.mustache);
    cpyPerso.accessory = strdup(perso.accessory);

    return cpyPerso;
}

int alreadyExist(PtListe allPerso, persoCharacteristic perso) {		// vérifie l'existence d'un personnage dans la liste
    if (allPerso == NULL) return 0;
    else if (!strcmp(allPerso->character.name, perso.name)) return 1;
    else return alreadyExist((PtListe)allPerso->suivant, perso);
}

int cmpBothCharacter(persoCharacteristic P1, persoCharacteristic P2) {	// compare les caractéritiques de deux personnages
    if (strcmp(P1.sexe, P2.sexe))                return 1;
    else if (strcmp(P1.name, P2.name))           return 1;
    else if (strcmp(P1.formes, P2.formes))       return 1;
    else if (strcmp(P1.longHair, P2.longHair))   return 1;
    else if (strcmp(P1.colorHair, P2.colorHair)) return 1;
    else if (strcmp(P1.eyes, P2.eyes))           return 1;
    else if (strcmp(P1.beard, P2.beard))         return 1;
    else if (strcmp(P1.mustache, P2.mustache))   return 1;
    else if (strcmp(P1.accessory, P2.accessory)) return 1;
    else return 0;
}

void printLoadingBar(int size) {				// barre de chargement
    int i;
    for (i = 0; i < size; i++) {
        printf("\rInitialisation du jeu : %d %c", i/100, '%');
        usleep(5);
    }
    printf("\rInitialisation du jeu : 100 %c", '%');
    printf("\n");
}

void showCharacter(persoCharacteristic perso) {
    printf("\tSexe               : %s\n", perso.sexe);
    printf("\tPrénom             : %s\n", perso.name);
    printf("\tForme du visage    : %s\n", perso.formes);
    printf("\tCheveux            : %s\n", perso.longHair);
    printf("\tCouleur de cheveux : %s\n", perso.colorHair);
    printf("\tYeux               : %s\n", perso.eyes);
    printf("\tBarbe              : %s\n", perso.beard);
    printf("\tMoustache          : %s\n", perso.mustache);
    printf("\tAccessoire         : %s\n\n", perso.accessory);
}

void showPersosMenu(persoCharacteristic myPerso, persoCharacteristic myPersoBis, persoCharacteristic otherPerso, PtListe allPerso) {
    printf("%sTous les personnages..................................%s\n", blue, white);
    showListe(allPerso);

    printf("%sMon personnage........................................%s\n", blue, white);
    printf("\tSexe               : %s", myPerso.sexe);
    if (!strcmp(myPersoBis.sexe, myPerso.sexe)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tPrénom             : %s  ", myPerso.name);
    if (!strcmp(myPersoBis.name, myPerso.name)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tForme du visage    : %s  ", myPerso.formes);
    if (!strcmp(myPersoBis.formes, myPerso.formes)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tCheveux            : %s  ", myPerso.longHair);
    if (!strcmp(myPersoBis.longHair, myPerso.longHair)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tCouleur de cheveux : %s  ", myPerso.colorHair);
    if (!strcmp(myPersoBis.colorHair, myPerso.colorHair)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tYeux               : %s  ", myPerso.eyes);
    if (!strcmp(myPersoBis.eyes, myPerso.eyes)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tBarbe              : %s  ", myPerso.beard);
    if (!strcmp(myPersoBis.beard, myPerso.beard)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tMoustache          : %s  ", myPerso.mustache);
    if (!strcmp(myPersoBis.mustache, myPerso.mustache)) printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\tAccessoire         : %s  ", myPerso.accessory);
    if (!strcmp(myPersoBis.accessory, myPerso.accessory))printf(" %s --> a été trouvé !%s\n", red, white);
    else printf("\n");
    printf("\n\n");


    printf("%sSon personnage........................................%s\n", blue, white);
    if (!strcmp(otherPerso.sexe,      "Inconnue")) printf("\tSexe               : %s\n", otherPerso.sexe);
    else printf("\tSexe               : %s%s%s\n", green, otherPerso.sexe, white);
    if (!strcmp(otherPerso.name,      "Inconnue")) printf("\tPrénom             : %s\n", otherPerso.name);
    else printf("\tPrénom             : %s%s%s\n", green, otherPerso.name, white);
    if (!strcmp(otherPerso.formes,    "Inconnue")) printf("\tForme du visage    : %s\n", otherPerso.formes);
    else printf("\tForme du visage    : %s%s%s\n", green, otherPerso.formes, white);
    if (!strcmp(otherPerso.longHair,  "Inconnue")) printf("\tCheveux            : %s\n", otherPerso.longHair);
    else printf("\tCheveux            : %s%s%s\n", green, otherPerso.longHair, white);
    if (!strcmp(otherPerso.colorHair, "Inconnue")) printf("\tCouleur de cheveux : %s\n", otherPerso.colorHair);
    else printf("\tCouleur de cheveux : %s%s%s\n", green, otherPerso.colorHair, white);
    if (!strcmp(otherPerso.eyes,      "Inconnue")) printf("\tYeux               : %s\n", otherPerso.eyes);
    else printf("\tYeux               : %s%s%s\n", green, otherPerso.eyes, white);
    if (!strcmp(otherPerso.beard,     "Inconnue")) printf("\tBarbes             : %s\n", otherPerso.beard);
    else printf("\tBarbes             : %s%s%s\n", green, otherPerso.beard, white);
    if (!strcmp(otherPerso.mustache,  "Inconnue")) printf("\tMoustache          : %s\n", otherPerso.mustache);
    else printf("\tMoustache          : %s%s%s\n", green, otherPerso.mustache, white);
    if (!strcmp(otherPerso.accessory, "Inconnue")) printf("\tAccessoire         : %s\n", otherPerso.accessory);
    else printf("\tAccessoire         : %s%s%s\n", green, otherPerso.accessory, white);
    printf("\n\n");
}

void printCharactersName(PtListe allPerso) {
    int i = 1;
    while (allPerso != NULL) {
        printf("%2d. %s\n", i, allPerso->character.name);
        i++;
        allPerso = (PtListe)allPerso->suivant;
    }
}

int getCptPerso(PtListe allPerso) {
    int cpt = 0;
    while (allPerso != NULL) {
        allPerso = (PtListe)allPerso->suivant;
        cpt++;
    }

    return cpt;
}

int playerQuestions(PtListe allPerso, persoCharacteristic persoOrdi){
    int target;
    int globalChoice, secondChoice;
    int testContinue = 0;
    int nbPerso = getCptPerso(allPerso);
    while (testContinue != 1) {
        printf("%sChoisisser une categorie.............................%s\n", blue, white);
        printf("1. Poser une question sur le sexe de la personne\n");
        printf("2. Poser une question sur le nom\n");
        printf("3. Poser une question sur la forme du visage\n");
        printf("4. Poser une question sur la longueur des cheveux\n");
        printf("5. Poser une question sur la couleur des cheveux\n");
        printf("6. Poser une question sur la couleur des yeux\n");
        printf("7. Poser une question sur la longeur de la barbe\n");
        printf("8. Poser une question sur la longeur de la moustache\n");
        printf("9. Poser une question sur la présence d'accessoire\n");

        printf("\nVotre choix : ");

        if (scanf("%d", &globalChoice) == 1) {
            if (globalChoice < 1 || globalChoice > 9) {
                printf("Valeur invalide --> recommencer\n");
                testContinue = 0;
            } else {
                testContinue = 1;
                target = globalChoice*10;
            }
        } else {
            printf("Input Error\n");
            testContinue = 0;
            exit(-1);
        }
    }

    testContinue = 0;

    switch(globalChoice) {
      case 1: //Sexe
        while (testContinue != 1) {
            char sexe[2][20] = {"homme", "femme"};
            printf("Quel est le sexe de l'individu ?\n");
            printf("1. Homme\n");
            printf("2. Femme\n");
            printf("\nVotre choix : ");
            if (scanf("%d", &secondChoice) == 1) {
                if (secondChoice < 1 || secondChoice > 2) {
                    printf("Valeur invalide --> recommencer !\n");
                    testContinue = 0;
                } else {
                  if(secondChoice == 1){
                    printf("Moi : Ton personnage est un %s ?\n",sexe[secondChoice - 1]);
                  }
                  else{
                    printf("Moi : Ton personnage est une %s ?\n", sexe[secondChoice - 1]);
                  }
                  target += secondChoice;
                  target *= 10;
                    if (!strcmp(sexe[secondChoice - 1], persoOrdi.sexe)) {
                        printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                        target += 1;
                    } else {
                        printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                        target += 0;
                        // deleteCharacter(allPerso,)
                    }
                    return target;
                }
            } else {
                printf("Input Error\n");
                testContinue = 0;
                exit(-1);
            }
        }
        break;

      case 2: //Nom
        while (testContinue != 1) {
            int i;
            char name[nbPerso][20];
            PtListe tmp = allPerso;
            for (i = 0; i < nbPerso; i++) {
                strcpy(name[i], tmp->character.name);
                tmp = (PtListe)tmp->suivant;
            }
            printf("Quelle est le nom de votre cible\n");
            printCharactersName(allPerso);
            printf("\nVotre choix : ");
            if (scanf("%d", &secondChoice) == 1) {
                if (secondChoice < 1 || secondChoice > nbPerso) {
                    printf("Valeur invalide --> recommencer !\n");
                    testContinue = 0;
                } else {
                    target += secondChoice;
                    target *= 10;
                    if (!strcmp(name[secondChoice - 1], persoOrdi.name)) {
                        printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                        target += 1;
                    } else {
                        printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                        target += 0;
                    }
                    return target;
                }
            } else {
                printf("Input Error\n");
                testContinue = 0;
                exit(-1);
            }
        }
      break;

      case 3: //forme visage
      while (testContinue != 1) {
          char form[3][20] = {"carré", "ovale", "rond"};
          printf("Quelle est la forme du visage ?\n");
          printf("1. Carré\n");
          printf("2. Ovale\n");
          printf("3. Rond\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 3) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                  target += secondChoice;
                  target *= 10;
                printf("Ton personnage a un visage %s ?\n", form[secondChoice - 1]);
                if (!strcmp(form[secondChoice - 1], persoOrdi.formes)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }

          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
      }
      break;

      case 4: //longueur cheveux
      while (testContinue != 1) {
          char longHair[3][20] = {"chauve", "long", "court"};
          printf("Quelle est la longueur des cheveux?\n");
          printf("1. Chauve\n");
          printf("2. Long\n");
          printf("3. Court\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 3) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {

                if(secondChoice == 1){
                  printf("Moi : Ton personnage est chauve ?\n");
                }
                else{
                  printf("Moi : Ton personnage a les cheveux %s ?\n", longHair[secondChoice - 1]);
                }
                target += secondChoice;
                target *= 10;
                if (!strcmp(longHair[secondChoice - 1], persoOrdi.longHair)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
      }
      break;

      case 5: //couleur cheveux
      while (testContinue != 1) {
          char colorHair[5][20] = {"noir", "brun","blond", "roux", "gris"};
          printf("Quelle est la couleur des cheveux?\n");
          printf("1. Noir\n");
          printf("2. Brun\n");
          printf("3. Blond\n");
          printf("4. Roux\n");
          printf("5. Gris\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 5) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                printf("Moi : Ton personnage a les cheveux de couleur %s ?\n",colorHair[secondChoice -1]);
                target += secondChoice;
                target *= 10;
                if (!strcmp(colorHair[secondChoice - 1], persoOrdi.colorHair)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
      }
      break;

      case 6: //Couleur yeux
      while (testContinue != 1) {
          char colorEyes[4][20] = {"noirs", "marrons","bleus", "verts"};
          printf("Quelle est la couleur des yeux?\n");
          printf("1. Noirs\n");
          printf("2. Marrons\n");
          printf("3. Bleus\n");
          printf("4. Verts\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 4) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                printf("Moi : Ton personnage a les yeux %s ?\n",colorEyes[secondChoice -1]);
                target += secondChoice;
                target *= 10;
                if (!strcmp(colorEyes[secondChoice - 1], persoOrdi.eyes)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
        }
      break;

      case 7: //Barbe
      while (testContinue != 1) {
          char beard[3][20] = {"aucun", "courte","longue"};
          printf("Quelle est la taille de la barbe ?\n");
          printf("1. Pas de Barbe\n");
          printf("2. Courte\n");
          printf("3. Longue\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 3) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                if(secondChoice == 1){
                  printf("Moi : Ton personnage n'a pas de barbe ?\n");
                }
                else{
                  printf("Moi : Ton personnage a une barbe %s ?\n",beard[secondChoice - 1]);
                }
                target += secondChoice;
                target *= 10;
                if (!strcmp(beard[secondChoice - 1], persoOrdi.beard)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
        }
      break;

      case 8: //moustache
      while (testContinue != 1) {
          char moustache[3][20] = {"aucun", "courte","longue"};
          printf("Quelle est la taille de la barbe ?\n");
          printf("1. Pas de moustache\n");
          printf("2. Courte\n");
          printf("3. Longue\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 3) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                if(secondChoice == 1){
                  printf("Moi : Ton personnage n'a pas de moustache ?\n");
                }
                else{
                  printf("Moi : Ton personnage a une %s moustache ?\n",moustache[secondChoice - 1]);
                }
                target += secondChoice;
                target *= 10;
                if (!strcmp(moustache[secondChoice - 1], persoOrdi.mustache)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
        }
      break;

      case 9: //accesoires
      while (testContinue != 1) {
          char accessory[3][20] = {"aucun", "lunettes","chapeau"};
          printf("Ton personnage a un accesoire ?\n");
          printf("1. Aucun\n");
          printf("2. Lunettes\n");
          printf("3. Chapeau\n");
          printf("\nVotre choix : ");
          if (scanf("%d", &secondChoice) == 1) {
              if (secondChoice < 1 || secondChoice > 3) {
                  printf("Valeur invalide --> recommencer !\n");
                  testContinue = 0;
              } else {
                if(secondChoice == 1){
                  printf("Moi : Ton personnage n'a pas d'accesoire ?\n");
                }
                if(secondChoice == 2){
                  printf("Moi : Ton personnage a des lunettes ?\n");
                }
                else{
                  printf("Moi : Ton personnage a un chapeau ?\n");
                }
                target += secondChoice;
                target *= 10;
                if (!strcmp(accessory[secondChoice - 1], persoOrdi.accessory)) {
                    printf("Ordi : BIP! REPONSE CORRECTE\n\n");
                    target += 1;
                } else {
                    printf("Ordi : BIP BIP! REPONSE INCORRECTE\n\n");
                    target += 0;
                }
                return target;
            }
          } else {
              printf("Input Error\n");
              testContinue = 0;
              exit(-1);
          }
        }
      break;
    }

    return target;
}

int computerQuestions(PtListe allPerso, persoCharacteristic persoJoueur,
	persoCharacteristic persoTargetComputer) {
    int first;
    int second;
    int target;
    int testQuestion = 0;

    first   = rand()%8+1;
    target  = first;
    target *= 10;

    while (testQuestion != 1) {
        if (first == 1 && !strcmp(persoTargetComputer.sexe, "Inconnue")) {
            testQuestion = 1;
            char sexe[2][20] = {"homme" , "femme"};

            second  = rand()%1;
            target += second + 1;
            target *= 10;

            printf("Ordi : GENRE -> %s ?\n", sexe[second]);

            if (!strcmp(sexe[second], persoJoueur.sexe)) {
                if (second == 0) {
                    printf("Moi : Oui, mon personnage est un homme\n\n");
                    target += 1;
                } else {
                    printf("Moi : Oui, mon personnage est une femme\n\n");
                    target += 1;
                }
            } else {
                if (second == 0) {
                    printf("Moi : Non, mon personnage n'est pas un homme\n\n");
                    target += 0;
                }
                printf("Moi : Non, mon personnage n'est pas une femme\n\n");
                target += 0;
            }
            return target;
        }

        else if (first == 2 && !strcmp(persoTargetComputer.name, "Inconnue")) {
            testQuestion = 1;
            // char name[14][20]= {"Jérémy", "Felix", "Sofiane", "Thomas", "Paul", "Jean-Marc","Jason","Jeannine","Martine","Aurore","Lise","Manon","Sylvie","Alexia"};

            int i;
            int nbPerso = getCptPerso(allPerso);
            char name[nbPerso][20];
            PtListe tmp = allPerso;
            for (i = 0; i < nbPerso; i++) {
                strcpy(name[i], tmp->character.name);
                tmp = (PtListe)tmp->suivant;
            }


            second  = rand()%nbPerso;
            target += second + 1;
            target *= 10;

            printf("Ordi : NOM -> %s ?\n", name[second]);
            if (!strcmp(name[second], persoJoueur.name)) {
                printf("Joueur : Oui, mon personnage s'appelle %s\n\n",  name[second]);
                target += 1;
            } else {
                printf("Joueur : Non, mon personnage ne s'appelle pas %s\n\n",  name[second]);
                target += 0;
            }
            return target;
        }
        else if (first == 3 && !strcmp(persoTargetComputer.formes, "Inconnue")) {
            testQuestion = 1;
            char formes[3][20]= {"carré", "ovale", "rond"};

            second  = rand()%2;
            target += second + 1;
            target *= 10;

            printf("Ordi : FORMES VISAGE -> %s ?\n", formes[second]);
            if (!strcmp(formes[second], persoJoueur.formes)) {
                printf("Moi : Oui, il a le visage %s !\n\n", formes[second]);
                target += 1;
            } else {
                printf("Moi : Non, il n'a pas le visage %s\n\n", formes[second]);
                target += 0;
            }
            return target;
        }
        else if (first == 4 && !strcmp(persoTargetComputer.longHair, "Inconnue")) {
            testQuestion = 1;
            char longHair[3][20]  = {"chauve", "court", "long"};

            second  = rand()%2;
            target += second + 1;
            target *= 10;

            printf("Ordi : TAILLE CHEVEUX -> %s ?\n", longHair[second]);
            if (!strcmp(longHair[second], persoJoueur.longHair)) {
                if (second == 0) {
                    printf("Moi : Oui, mon personnage est chauve\n\n");
                    target += 1;
                } else {
                    printf("Moi : Oui, mon personnage a les cheveux %s\n\n", longHair[second]);
                    target += 1;
                }
            } else {
                if (second == 0) {
                    printf("Moi : Non, mon personnage n'est pas chauve\n\n");
                    target+=0;
                } else {
                    printf("Moi : Non, mon personnage n'as pas les cheveux %s\n\n", longHair[second]);
                    target += 0;
                }
            }
            return target;
        }
        else if (first == 5 && !strcmp(persoTargetComputer.colorHair, "Inconnue")) {
              testQuestion = 1;
              char colorHair[5][20] = {"noir"  , "brun"    , "blond"  , "roux"  , "gris"};

              second  = rand()%4;
              target += second + 1;
              target *= 10;

              printf("Ordi : COULEUR CHEVEUX -> %s ?\n",colorHair[second]);
              if (!strcmp(colorHair[second], persoJoueur.colorHair)) {
                  printf("Moi : Oui, mon personnage a les cheveux %s\n\n", colorHair[second]);
                  target += 1;
                } else {
                    target += 0;
                    printf("Moi : Non, mon personnage n'a pas les cheveux %s\n\n", colorHair[second]);
                }
                return target;
        }
        else if (first == 6 && !strcmp(persoTargetComputer.eyes, "Inconnue")) {
            testQuestion = 1;
            char eyes[4][20]= {"noirs", "marrons", "bleus", "verts"};

            second=rand()%3;
            target += second + 1;
            target *= 10;

            printf("Ordi : COULEUR YEUX -> %s ?\n", eyes[second]);
            if (!strcmp(eyes[second], persoJoueur.eyes)) {
                printf("Moi : Oui, mon personnage a les yeux %s\n\n", eyes[second]);
                target += 1;
            } else {
                printf("Moi : Non, mon personnage n'a pas les yeux %s\n\n", eyes[second]);
                target += 0;
            }
            return target;
        }
        else if (first == 7 && !strcmp(persoTargetComputer.beard, "Inconnue")) {
            testQuestion = 1;
            char beard[3][20]= {"aucun", "courte", "longue"};
            second=rand()%2;
            target += second + 1;
            target *= 10;
            printf("Ordi : TAILLE BARBE -> %s ?\n", beard[second]);
            if (!strcmp(beard[second], persoJoueur.beard)) {
              if (second == 0){
                printf("Moi : Oui, mon personnage n'as pas de barbe !\n\n");
                target += 1;
              }
              else {
                printf("Moi : Oui, mon personnage a une barbe %s\n\n", beard[second]);
                target += 1;
              }
            } else {
              if (second == 0) {
                printf("Moi : Non, mon personnage a une barbe !\n\n");
                target += 0;
              }
              else{
                printf("Moi : Non, mon personnage n'as pas une barbe %s!\n\n", beard[second]);
                target += 0;
              }
            }
            return target;
        }

        else if (first == 8 && !strcmp(persoTargetComputer.mustache, "Inconnue")) {
            testQuestion = 1;
            char mustache[3][20]  = {"aucun" , "courte", "longue"};
            second=rand()%2;
            target += second + 1;
            target *= 10;
            printf("Ordi : TAILLE MOUSTACHE -> %s ?\n", mustache[second]);
            if (!strcmp(mustache[second], persoJoueur.mustache)) {
              if (second == 0) {
                printf("Moi : Oui, mon personnage n'as pas de moustache !\n\n");
                target += 1;
              }
              else {
                printf("Moi : Oui, mon personnage a une %s moustache\n\n",mustache[second]);
                target += 1;
              }
            }
            else{
              if(second == 0){
                printf("Moi : Non, mon personnage a une moustache !\n\n");
                target += 0;
              }
              else{
                printf("Moi : Non, mon personnage n'as pas une %s moustache!\n\n",mustache[second]);
                target+=0;
              }
            }
            return target;
        }

        else if (first == 9 && !strcmp(persoTargetComputer.accessory, "Inconnue")) {
            testQuestion = 1;
            char accessory[3][20] = {"aucun" , "lunettes", "chapeau"};
            second=rand()%2;
            target += second + 1;
            target *= 10;
            printf("Ordi : ACCESSOIRE -> %s ?\n", accessory[second]);
            if (!strcmp(accessory[second], persoJoueur.accessory)) {
              if (second == 0) {
                printf("Moi : Oui, mon personnage n'as pas d'accesoire !\n\n");
                target += 1;
              }
              if (second == 1) {
                printf("Moi : Oui, mon personnage a des lunettes !\n\n");
                target += 1;
              } else {
                printf("Moi : Oui, mon personnage a un chapeau !\n\n");
                target += 1;
              }
            }
            else {
              if (second == 0) {
                printf("Moi : Non, mon personnage a un accesoire\n\n");
                target += 0;
              }
              if (second == 1) {
                printf("Moi : Non, mon personnage n'as pas de lunettes\n\n");
                target += 0;
              } else{
                printf("Moi : Non, mon personnage n'as pas de chapeau\n\n");
              }
            }
            return target;
        }
        else {
            first = rand()%9;
            testQuestion = 0;
        }
    }

    return 0;
}

void updateCharacteristic(PtListe allPerso, persoCharacteristic *persoTarget, int target) {
    int questionCategory     = target/100;			// récupère la catégorie
    int questionSubCategory  = (target/10)%10;		// récupère la sous categorie
    int isTrue               = target%10;			// récupère l'etat de l'information

    int i;
    int nbPerso = getCptPerso(allPerso);
    char subName[nbPerso][20];
    PtListe tmp = allPerso;
    for (i = 0; i < nbPerso; i++) {
        strcpy(subName[i], tmp->character.name);
        tmp = (PtListe)tmp->suivant;
    }

    questionSubCategory     -= 1;
    char subSexe[2][20]      = {"homme" , "femme"};
    char subFormes[3][20]    = {"carré" , "ovale"   , "rond"};
    char subLongHair[3][20]  = {"chauve", "long"    , "court"};
    char subColorHair[5][20] = {"noir"  , "brun"    , "blond"  , "roux"  , "gris"};
    char subEyes[4][20]      = {"noirs" , "marrons" , "bleus"  , "verts"};
    char subBeard[3][20]     = {"aucun" , "courte"  , "longue"};
    char subMustache[3][20]  = {"aucun" , "courte"  , "longue"};
    char subAccessory[3][20] = {"aucun" , "lunettes", "chapeau"};

    if (questionCategory == 1) {
        if (isTrue) strcpy(persoTarget->sexe, subSexe[questionSubCategory]);
        else strcpy(persoTarget->sexe, subSexe[(questionSubCategory+1)%2]);
    }
    else if (questionCategory == 2 && isTrue) strcpy(persoTarget->name,      subName[questionSubCategory]);
    else if (questionCategory == 3 && isTrue) strcpy(persoTarget->formes,    subFormes[questionSubCategory]);
    else if (questionCategory == 4 && isTrue) strcpy(persoTarget->longHair,  subLongHair[questionSubCategory]);
    else if (questionCategory == 5 && isTrue) strcpy(persoTarget->colorHair, subColorHair[questionSubCategory]);
    else if (questionCategory == 6 && isTrue) strcpy(persoTarget->eyes,      subEyes[questionSubCategory]);
    else if (questionCategory == 7 && isTrue) strcpy(persoTarget->beard,     subBeard[questionSubCategory]);
    else if (questionCategory == 8 && isTrue) strcpy(persoTarget->mustache,  subMustache[questionSubCategory]);
    else if (questionCategory == 9 && isTrue) strcpy(persoTarget->accessory, subAccessory[questionSubCategory]);
}

PtListe updateListe(PtListe allPerso, persoCharacteristic persoTarget, int target) {
    PtListe tmpListe = allPerso;

    while (tmpListe != NULL) {
        if (strcmp(tmpListe->character.sexe,      persoTarget.sexe)      && strcmp(persoTarget.sexe, "Inconnue"))      allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.name,      persoTarget.name)      && strcmp(persoTarget.name, "Inconnue"))      allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.formes,    persoTarget.formes)    && strcmp(persoTarget.formes, "Inconnue"))    allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.longHair,  persoTarget.longHair)  && strcmp(persoTarget.longHair, "Inconnue"))  allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.colorHair, persoTarget.colorHair) && strcmp(persoTarget.colorHair, "Inconnue")) allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.eyes,      persoTarget.eyes)      && strcmp(persoTarget.eyes, "Inconnue"))      allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.beard,     persoTarget.beard)     && strcmp(persoTarget.beard, "Inconnue"))     allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.mustache,  persoTarget.mustache)  && strcmp(persoTarget.mustache, "Inconnue"))  allPerso = deleteOneCharacter(allPerso, tmpListe);
        if (strcmp(tmpListe->character.accessory, persoTarget.accessory) && strcmp(persoTarget.accessory, "Inconnue")) allPerso = deleteOneCharacter(allPerso, tmpListe);
        tmpListe = (PtListe)tmpListe->suivant;
    }

    return allPerso;
}

void startMenu(int *level) {
    int testTrue = 0;
    while (testTrue != 1) {
        printf("%s____________________/%s  BIENVENUE SUR %s \\____________________%s\n",blue,white,blue, white);
        printf("                    %s\\%s  QUI EST CE  ?  %s/%s \n",blue,white,blue,white);
        printf("\nVeuillez choisir votre difficulté (entre 1 et 3) : ");
        if (scanf("%d", &*level) != 1) {
            printf("Input Error\n");
            exit(-1);
        }
        if (*level >= 1 || *level <= 3) testTrue = 1;
    }
}

void initGame(PtListe *allPerso, persoCharacteristic *myPerso, persoCharacteristic *otherPerso, int level) {
    int nbPerso;
    int posPersoPlayer, posPersoComputer;
    persoCharacteristic tmpPerso;
    if (level == 1) nbPerso = 5;
    if (level == 2) nbPerso = 10;
    if (level == 3) nbPerso = 20;

    posPersoPlayer   = rand()%nbPerso;
    posPersoComputer = rand()%nbPerso;

    int i;
    for (i = 0; i < nbPerso; i++) {
        tmpPerso = createCharacter(*allPerso);
        *allPerso = inserthead(*allPerso, tmpPerso);
        if (i == posPersoPlayer)   *myPerso    = tmpPerso;
        if (i == posPersoComputer) *otherPerso = tmpPerso;
    }
    printf("%s____________________%s     NIVEAU %2d     %s____________________%s\n", blue, white, level, blue, white);
}

persoCharacteristic initUnknowPerso() {
    persoCharacteristic perso;              // Perso cible du joueur
    perso.sexe      = strdup("Inconnue");
    perso.name      = strdup("Inconnue");
    perso.formes    = strdup("Inconnue");
    perso.longHair  = strdup("Inconnue");
    perso.colorHair = strdup("Inconnue");
    perso.eyes      = strdup("Inconnue");
    perso.beard     = strdup("Inconnue");
    perso.mustache  = strdup("Inconnue");
    perso.accessory = strdup("Inconnue");
    return perso;
}

int runGame(PtListe allPersoP1, persoCharacteristic myPerso, PtListe allPersoP2, persoCharacteristic otherPerso) {
    int resultP1, resultP2;
    int winner = -1;
    persoCharacteristic persoTargetPlayer   = initUnknowPerso();              // Perso cible du joueur
    persoCharacteristic persoTargetComputer = initUnknowPerso();            // Perso cible de l'ordinateur

    while (winner == -1) {
        showPersosMenu(myPerso, persoTargetComputer, persoTargetPlayer, allPersoP1);
        printf("%sQUESTIONS ...........................................%s\n\n", blue, white);
        resultP1 = playerQuestions(allPersoP1, otherPerso);
		sleep(3);
        printf("\nOrdinateur...\n");
        resultP2 = computerQuestions(allPersoP2, myPerso, persoTargetComputer);

        sleep(3);

        updateCharacteristic(allPersoP1, &persoTargetPlayer,   resultP1); // Mise à jour de la liste du joueur
        updateCharacteristic(allPersoP2, &persoTargetComputer, resultP2); // Mise à jour de la liste de l'ordinateur

        allPersoP1 = updateListe(allPersoP1, persoTargetPlayer,   resultP1);
        allPersoP2 = updateListe(allPersoP2, persoTargetComputer, resultP2);

        if (strcmp(persoTargetPlayer.name,   "Inconnue") && strcmp(persoTargetComputer.name, "Inconnue")) winner = 2;
        else if (strcmp(persoTargetPlayer.name,   "Inconnue")) winner = 1;
        else if (strcmp(persoTargetComputer.name, "Inconnue")) winner = 0;
    }
    return winner;
}

void endOfGame(int winner) {
    char winnerName[2][20] = {"Ordinateur", "joueur"};
    printf("%s____________________%s FIN DE LA PARTIE %s____________________%s\n", blue, white, blue, white);
    if (winner == 0) {
        printf("\nL'%s est gagnant \n", winnerName[winner]);
        printf("Ordi : HA HA\n");
    	sleep(1);
    	printf("Ordi : JE T'AI BATTU\n");
    	sleep(1);
    	printf("Ordi : TU ES NUL\n");
			sleep(1);
    }
    else if (winner == 1){
          printf("\nLe %s est gagnant \n", winnerName[winner]);
          printf("Ordi : BIP !\n");
    	  sleep(1);
    	  printf("Ordi : TU M'AS BATTU\n");
    	  sleep(1);
    	  printf("Ordi : BIEN JOUÉ\n");
    	  sleep(1);
     }
    else if (winner == 2) {
          printf("Il n'y a pas de gagnant\n");
          printf("VOUS ETES VRAIMENT TROP FORT !\n");
    }

    printf("\nMerci d'avoir joué à notre jeu\n\n\n");
    printf("%s____________________/%s        A       %s \\____________________%s\n",blue,white,blue, white);
    printf("                    %s\\%s     BIENTOT     %s/%s \n",blue,white,blue,white);
}
