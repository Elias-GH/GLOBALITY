#ifndef H_LISTE
#define H_LISTE

    #include "structure.h"

    PtListe init();
    PtListe inserthead(PtListe L, persoCharacteristic newCharacter);
    PtListe deleteHead(PtListe L);
    PtListe deleteMiddle(PtListe myListe, PtListe target);
    PtListe deleteQueue(PtListe L);
    PtListe deleteCharacter(PtListe myListe, persoCharacteristic target);
    PtListe deleteOneCharacter(PtListe L, PtListe myListe);
    void showListe(PtListe L);
    int sizeOfListe(PtListe myListe);
    PtListe cloneListe(PtListe myListe);

#endif
