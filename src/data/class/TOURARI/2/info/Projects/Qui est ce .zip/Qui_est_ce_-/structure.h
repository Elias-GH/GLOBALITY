#ifndef H_STRUCTURE
#define H_STRUCTURE

    typedef struct {
        char *sexe;         // femme, homme
        char *name;         // Nom personnage
        char *formes;       // carré, ovale, rond
        char *longHair;     // Aucun, Long et court
        char *colorHair;    // Noir, Brun, Blond,Roux, Gris
        char *eyes;         // Noirs, Marrons, Bleus, Verts
        char *beard;        // aucun, courte, longue
        char *mustache;     // aucun, courte, longue
        char *accessory;    // aucun, lunette, chapeau
    } persoCharacteristic;

    typedef struct {
        persoCharacteristic character;
        struct Liste *suivant;
    } Liste, *PtListe;

#endif
