#ifndef H_CHARACTER
#define H_CHARACTER
    #include "structure.h"

    void clearScreen();
    persoCharacteristic createCharacter();
    persoCharacteristic copyCharacter(persoCharacteristic perso);
    int  alreadyExist(PtListe allPerso, persoCharacteristic perso);
    int  cmpBothCharacter(persoCharacteristic P1, persoCharacteristic P2);
    void printLoadingBar(int size);
    void showCharacter(persoCharacteristic character);
    void showPersosMenu(persoCharacteristic myPerso, persoCharacteristic myPersoBis, persoCharacteristic otherPerso, PtListe allPerso);
    void printCharactersName(PtListe allPerso);
    int  getCptPerso();
    int  playerQuestions(PtListe allPerso, persoCharacteristic persoOrdi);
    int computerQuestions(PtListe allPerso, persoCharacteristic persoJoueur, persoCharacteristic persoTargetComputer);
    void updateCharacteristic(PtListe allPerso, persoCharacteristic *persoTarget, int target);
    PtListe updateListe(PtListe allPerso, persoCharacteristic persoTarget, int target);

    void startMenu(int *level);
    void initGame(PtListe *allPerso, persoCharacteristic *myPerso, persoCharacteristic *otherPerso, int level);
    persoCharacteristic initUnknowPerso();
    int  runGame(PtListe allPersoP1, persoCharacteristic myPerso, PtListe allPersoP2, persoCharacteristic otherPerso);
    void endOfGame(int winner);
#endif
