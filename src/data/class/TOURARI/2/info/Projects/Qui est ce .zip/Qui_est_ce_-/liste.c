#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "structure.h"
#include "character.h"
#include "liste.h"

PtListe init() {
    return NULL;
}

PtListe inserthead(PtListe L, persoCharacteristic newCharacter){
    PtListe P = (Liste*)malloc(sizeof(Liste));
    P->character = newCharacter;
    P->suivant   = L;

    return P;
}

PtListe deleteHead(PtListe L) {
    PtListe P;
    P = L;
    if (L != NULL) {
        P = (PtListe)L->suivant;
        free(L);
    }
    return P;
}

PtListe deleteMiddle(PtListe myListe, PtListe target) {
    PtListe courant, successeur, Ltemp;
    if (myListe == NULL) return NULL;
    else if (myListe->suivant == NULL) {
        free(myListe);
        return NULL;
    }
    else {
        Ltemp = myListe;
        courant = Ltemp;
        successeur = Ltemp;
        while ((PtListe)successeur->suivant != target) {
            courant = successeur;
            successeur = (PtListe)successeur->suivant;
        }
        courant->suivant = target;
        free(successeur);
        return Ltemp;
    }
}

PtListe deleteQueue(PtListe L) {
    PtListe courant, successeur, Ltemp;
    if (L == NULL) return NULL;
    else if (L->suivant == NULL) {
        free(L);
        return NULL;
    }
    else {
        Ltemp = L;
        courant = Ltemp;
        successeur = Ltemp;
        while (successeur->suivant != NULL) {
            courant = successeur;
            successeur = (PtListe)successeur->suivant;
        }
        courant->suivant = NULL;
        free(successeur);
        return Ltemp;
    }
}

PtListe deleteCharacter(PtListe myListe, persoCharacteristic target){
    PtListe L;
    if (myListe == NULL) return NULL;
    else {
        L = myListe;
        while (L != NULL) {
            if (!strcmp(L->character.name, target.name)) {
                if (L == myListe) {
                    myListe = deleteHead(myListe);
                    break;
                }
                else if (L != myListe && L->suivant != NULL) myListe = deleteMiddle(myListe, (PtListe)L->suivant);
                else if (L->suivant == NULL) myListe = deleteQueue(myListe);
            }
            L = (PtListe)L->suivant;
        }
    }
    return myListe;
}

PtListe deleteOneCharacter(PtListe myListe, PtListe L) {
    if (L == myListe) {
        myListe = deleteHead(myListe);
    }
    else if (L != myListe && L->suivant != NULL) myListe = deleteMiddle(myListe, (PtListe)L->suivant);
    else if (L->suivant == NULL) myListe = deleteQueue(myListe);

    return myListe;
}

void showListe(PtListe L) {
    if (L == NULL) printf("Fin de la liste de personnage\n\n");
    else {
        showCharacter(L->character);
        showListe((PtListe)L->suivant);
    }
}

int sizeOfListe(PtListe myListe) {
    if (myListe == NULL) return 0;
    else return 1 + sizeOfListe((PtListe)myListe->suivant);
}

PtListe cloneListe(PtListe myListe) {
    PtListe otherListe = init();
    while (myListe != NULL) {
        otherListe = inserthead(otherListe, myListe->character);
        myListe = (PtListe)myListe->suivant;
    }

    return otherListe;
}
