#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "character.h"
#include "liste.h"

#define NB_PERSO 40

int main(int argc, char *argv[]) {
    // target = 123 --> 1 categorie : sexe --> 2 sous categorie : homme / femme --> 3 vrai/faux 1 : vrai / 2 : faux
    srand(time(NULL));                      // Créer un aléatoire à la racine
    int stateOfGame;                        // Etat du jeu --> valeur du vainqueur 1 : utilisateur - 0 : ordinateur
    int level;                              // Niveau de difficulter
    PtListe allPersoGLB      = init();      // Liste de tous les personnages
    PtListe allPersoPlayer   = init();      // Liste de tous les personnages pour le joueur
    PtListe allPersoComputer = init();      // Liste de tous les personnages pour l'ordinateur
    persoCharacteristic myPerso;            // caractéristiques du personnage du joueurs
    persoCharacteristic otherPerso;         // caractéristiques du personnage de l'ordinateur

    clearScreen();
    startMenu(&level);                      // Menu de démarage --> selection du niveau
    printLoadingBar(10000);
    initGame(&allPersoGLB, &myPerso, &otherPerso, level);   // Inialisation di jeu avec valeur de base
    allPersoComputer = cloneListe(allPersoGLB); //Liste des persos que voit l'ordi
    allPersoPlayer   = cloneListe(allPersoGLB); //Liste des persos que voit le joueur
    stateOfGame      = runGame(allPersoPlayer, myPerso, allPersoComputer, otherPerso);
    endOfGame(stateOfGame);

    return 0;
}
