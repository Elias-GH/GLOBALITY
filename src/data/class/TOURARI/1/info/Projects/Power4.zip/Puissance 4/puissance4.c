#include <stdio.h>
#include <stdlib.h>
#define NBLIN 6
#define NBCOL 7

int i, j, k, l, m, n;

void initArray(int nbLin, int nbCol, int board[nbLin][nbCol], int value){	//OK
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			board[i][j] = value;
		}
	}
}

void showArray(int nbLin, int nbCol, int board[nbLin][nbCol]){			//OK
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			printf("%3d", board[i][j]);
		}
		printf("\n");
	}
}

void clearScreen() {
	printf("%c[2J", 0x1B);
	printf("%c[%d;%dH", 0x1B, 1, 1);
}

void showBoard(int nbLin, int nbCol, int board[nbLin][nbCol]){			//OK
	clearScreen();

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			printf("|");
			if (board[i][j] == 0){
				printf("   ");
			}
			if (board[i][j] == 1){
				printf("\033[31;01m o\033[00m ");
			}
			if (board[i][j] == 2){
				printf("\033[36;01m o\033[00m ");
			}
			//printf("|");
		}
		printf("|");
		printf("\n");
	}
	printf(" ");
	for (j = 0; j < nbCol; j++){
		printf("--- ");
	}
	printf("\n");
	for (k = 0; k < nbCol; k++){
		printf("%3d", k);
		printf(" ");
	}
	printf("\n");
}

int getColumnForPawn(int nbLin, int nbCol, int board[nbLin][nbCol]){	//OK
	int colNumber = -1;

	while (colNumber == -1){
		printf("Enter the coordinate of the column you want to put your pawn on: ");

		if (scanf("%d",&colNumber) != 1){
			printf("Input Error\n");
			exit(-1);
		}
		if (colNumber < 0){
			printf("Wrong number of column (outside of the board), please re-try.\n");
			colNumber = -1;
		}
		if (colNumber > nbCol-1){
			printf("Wrong number of column (outside of the board), please re-try.\n");
			colNumber = -1;
		}
		if (board[0][colNumber] != 0){
			printf("\nThis column is full so you can't add any more pawn, please re-try.\n");
			colNumber = -1;
		}
	}
	return colNumber;
}

int placePawn(int nbLin, int nbCol, int board[nbLin][nbCol], int pownCol, int pown){	//OK
	int i = 0;
	int test = 0;
	int numLin;

	while (test == 0){
		if (board[nbLin - 1 - i][pownCol] == 0){
			numLin = nbLin - 1 - i;
			board[numLin][pownCol] = pown;
			test = 1;
		}
		i++;
	}

	return numLin;
}

int checkFourInLine(int nbLin, int nbCol, int board[nbLin][nbCol], int pownLin, int pownCol){	//OK


		int cptH = 1;
		int cptV = 1;

		int cptHDBG = 1;
		int cptHGBD = 1;
		int cptBGHD = 1;
		int cptBDHG = 1;

		int i = 1;
		int j = 1;
		int k = 1;
		int l = 1;
		int m = 1;
		int n = 1;
		int o = 1;
		int p = 1;

		//Verticale	OK
		while ( (board[pownLin - i][pownCol] == board[pownLin][pownCol] ) && ( (pownLin-i < nbLin) && (pownCol < nbCol) )){
			cptV++;
			i++;
		}
		while ( (board[pownLin + j][pownCol] == board[pownLin][pownCol] ) && ( (pownLin+j < nbLin) && (pownCol < nbCol) )){
			cptV++;
			j++;
		}

		//Horizontale	OK
		while ( ( board[pownLin][pownCol - k] == board[pownLin][pownCol] ) && ( (pownLin < nbLin) && (pownCol-k < nbCol) )){
			cptH++;
			k++;
		}
		while ( ( board[pownLin][pownCol + l] == board[pownLin][pownCol] ) && ( (pownLin < nbLin) && (pownCol+l < nbCol) )){
			cptH++;
			l++;
		}

		//Diagonale Bas Gauche -> Haut Droite
		while ( ( board[pownLin - m][pownCol + m] == board[pownLin][pownCol] ) && ( (pownLin-m < nbLin) && (pownCol+m < nbCol) )){
	    //printf("(%d, %d) : %d\n", pownCol + m, pownLin - m, board[pownLin - m][pownCol + m]);
	    cptBGHD++;
			m++;
		}
		//Diagonale Haut Doit -> Bas Gauche
		while ( (board[pownLin + o][pownCol - o] == board[pownLin][pownCol] ) && ( (pownLin+o < nbLin) && (pownCol-o < nbCol) )){
			cptHDBG++;
			o++;
		}
		//Diagonale Haut Gauche -> Bas Droit
		while ( (board[pownLin + n][pownCol + n] == board[pownLin][pownCol] ) && ( (pownLin+n < nbLin) && (pownCol+n < nbCol) )){
			cptHGBD++;
			n++;
		}
		//Diagonal Bas Droit -> Haut Gauche
		while ( (board[pownLin - p][pownCol - p] == board[pownLin][pownCol] ) && ( (pownLin-p < nbLin) && (pownCol-p < nbCol) )){
			cptBDHG++;
			p++;
		}

	if (cptV >= 4 || cptH >= 4 || cptBGHD >= 4 || cptHDBG >= 4 || cptHGBD >= 4 || cptBDHG >= 4) {
		return 1;
	}
	else {
		return 0;
	}
}

int runAStep(int nbLin, int nbCol, int board[nbLin][nbCol], int numPlayer){	//OK
	int pownCol;
	int pownLin;

	int testFourP1;
	int testFourP2;

	printf("\n#### Player %d, your turn ####\n", numPlayer);

	if (numPlayer == 1){
		pownCol = getColumnForPawn(nbLin, nbCol, board);	//OK

		pownLin = placePawn(nbLin, nbCol, board, pownCol, numPlayer);	//OK

		testFourP1 = checkFourInLine(nbLin, nbCol, board, pownLin, pownCol);	//OK
	}

	if (numPlayer == 2){
		pownCol = getColumnForPawn(nbLin, nbCol, board);	//OK

		pownLin = placePawn(nbLin, nbCol, board, pownCol, numPlayer);	//OK

		testFourP2 = checkFourInLine(nbLin, nbCol, board, pownLin, pownCol);	//OK
	}

	if (testFourP1 == 1 || testFourP2 == 1){
		return 1;
	}
	else {
		return 0;
	}
}

int runGame(int nbLin, int nbCol, int board[nbLin][nbCol]){
	int flag = 1;
	int steps = (nbLin * nbCol)-1;
	int numPlayer;
	int winTest;
	int winner;

	numPlayer = 1;

	do {
	//////////// NUMBER OF PLAYER WHO IS PLAYING //////////
		if (numPlayer > 2){
			numPlayer = 1;
		}
	///////////// RUN STEP /////////////////////

		winTest = runAStep(nbLin, nbCol, board, numPlayer);

		showBoard(nbLin, nbCol, board);

	//////////// TEST OF ENDING GAME ////////////////
		if (winTest == 1){
			flag = 0;
			winner = numPlayer;
		}
		else if (steps == 0){
			flag = 0;
			winner = steps;
		}
		else {
			flag = 1;
		}

		steps--;
		numPlayer++;

	} while (flag == 1);

	printf("WinTest : %d\n", winTest);
	printf("Steps : %d\n", steps);

	return winner;
}

void endGame(int numWinner){
	printf("\n\n#### THE GAME IS OVER ####\n");
	if (numWinner == 0){
		printf("\nIt's a draw!\n");
	}
	else {
		printf("\nAnd the winner is Player %d!\n", numWinner);
	}
}

int main() {
	int board[NBLIN][NBCOL];
	int winner;

	initArray(NBLIN, NBCOL, board, 0);

	showBoard(NBLIN, NBCOL, board);

	winner = runGame(NBLIN, NBCOL, board);

	endGame(winner);
	return 0;
}
