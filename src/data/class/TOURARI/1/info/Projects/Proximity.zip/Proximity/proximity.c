#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NBLIN 10
#define NBCOL 10
#define STEPS 2

int a, b, c, i, j;

void initArray(int nbLin, int nbCol, int iArray[nbLin][nbCol], int value){	//OK
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			iArray[i][j] = value;
		}
	}
}

void clearScreen(){		//OK
	printf("%c[2J", 0x1B);
	printf("%c[%d;%dH", 0x1B, 1, 1);
}

void showArray(int nbLin, int nbCol, int iArray[nbLin][nbCol]){	//OK
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			printf("%3d", iArray[i][j]);
		}
		printf("\n");
	}
}

void showBoard(int nbLin, int nbCol, int board[nbLin][nbCol]){	//OK
	clearScreen();

	printf("   j");
	for (a = 0; a < nbCol; a++){
		printf("%3d ", a);
	}
	printf("\n");
	printf("  i ");
	for (b = 0; b < nbLin; b++){
		printf("--- ");
	}
	printf("\n");
	for (i = 0; i < nbLin; i++){
		printf("%3d|", i);
		for (j = 0; j < nbCol; j++){
			if (board[i][j] == 0){
				printf("%3d ", board[i][j]);
			}
			if (board[i][j] > 0){
				printf("\033[31;01m%3d \033[00m", board[i][j]);
			}
			if (board[i][j] < 0){
				printf("\033[36;01m%3d \033[00m", board[i][j]*-1);
			}
		}
		printf("\n");
	}
}

int getNextUnitForce(){	//OK
	int value;
	value = rand()%19+1;

	return value;
}

void placeUnitForce(int nbLin, int nbCol, int board[nbLin][nbCol], int value, int ufCoord[]){		//OK
	int test;
	int testBoard;
	int testPos;

	while (test != 0){
		testPos = 0;
		testBoard = 0;
		printf("Enter the coordinates i and j of the case you want to put your UF on: ");
		for (i = 0; i < 2; i++){
			if (scanf("%d", &ufCoord[i]) != 1){
				printf("Input error\n");
				exit(-1);
			}
		}

		if (ufCoord[1] > nbCol || ufCoord[1] < 0){
			printf("Wrong coordinates (outside of the board), please re-try.\n");
			testPos = 1;
		}
		if (ufCoord[0] > nbLin || ufCoord[0] < 0){
			printf("Wrong coordinates (outside of the board), please re-try.\n");
			testPos = 1;
		}
		if (board[ufCoord[0]][ufCoord[1]] != 0){
			printf("\nCell allready full, please re-try.\n");
			testPos = 1;
		}
		if (testPos == 0 && testBoard == 0){
			test = 0;
		}
	}
	board[ufCoord[0]][ufCoord[1]] = value;	//OK
	printf("(%d, %d) : %d\n", ufCoord[0], ufCoord[1], board[ufCoord[0]][ufCoord[1]]);	//OK
}

void affectNeightborhood(int nbLin, int nbCol, int board[nbLin][nbCol], int groundLin, int groundCol){ //KO
	int numPlayer;

	if (board[groundLin][groundCol] > 0){
		numPlayer = 1;
	}
	else if (board[groundLin][groundCol] < 0){
		numPlayer = 2;
	}

	if (numPlayer == 1){
		for (i = groundLin-1; i <= groundLin+1; i++){
			for (j = groundCol-1; j <= groundCol+1; j++){
				if ( (i != groundLin || j != groundCol) && ((i >= 0 && i <= nbLin-1) && (j >= 0 && j <= nbCol-1)) ){
					if (board[i][j] > 0){
						board[i][j]+=1;
					}
					if (board[i][j] < 0 && board[i][j]*-1 < board[groundLin][groundCol]){
						board[i][j]*=-1;
					}
				}
			}
		}
	}

	if (numPlayer == 2){
		for (i = groundLin-1; i <= groundLin+1; i++){
			for (j = groundCol-1; j <= groundCol+1; j++){
				if ( (i != groundLin || j != groundCol) && ((i >= 0 && i <= nbLin-1) && (j >= 0 && j <= nbCol-1)) ){
					if (board[i][j] < 0){
						board[i][j]-=1;
					}
					if (board[i][j] > 0 && board[i][j] < board[groundLin][groundCol]*-1){
						board[i][j]*=-1;
					}
				}
			}
		}
	}
}

int getNumberOfTerritoriesForPlayer(int nbLin, int nbCol, int board[nbLin][nbCol], int numPlayer){
	int cptPlayer = 0;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (numPlayer == 1 && board[i][j] > 0){
				cptPlayer++;
			}
			if (numPlayer == 2 && board[i][j] < 0){
				cptPlayer++;
			}
		}
	}
	return cptPlayer;
}

void runAStep(int nbLin, int nbCol, int board[nbLin][nbCol], int numPlayer){
	int ufCoord[2];
	int nextUnitForce = getNextUnitForce();

	printf("\n#### Player %d ####\nYour next Unit Force is %d\n", numPlayer, nextUnitForce);
	if (numPlayer == 1){
		nextUnitForce *=1;
		placeUnitForce(nbLin, nbCol, board, nextUnitForce, ufCoord);
		affectNeightborhood(nbLin, nbCol, board, ufCoord[0], ufCoord[1]);
	}
	if (numPlayer == 2){
		nextUnitForce *=-1;
		placeUnitForce(nbLin, nbCol, board, nextUnitForce, ufCoord);
		affectNeightborhood(nbLin, nbCol, board, ufCoord[0], ufCoord[1]);
	}
}

void endOfGame(int numWinner){
	printf("\n\n#### THE GAME IS OVER ####\n");
	if (numWinner == 0){
		printf("\nIt's a draw!\n");
	}
	else {
		printf("\nAnd the winner is Player %d!\n", numWinner);
	}
}

int runGame(int nbLin, int nbCol, int board[nbLin][nbCol]){
	int lastTurn = nbLin * nbCol;
	int numPlayer = 1;
	int winner;
	int territoriesPlayer1 = 0;
	int territoriesPlayer2 = 0;

	while (lastTurn != 0){
		runAStep(nbLin, nbCol, board, numPlayer);
		showBoard(nbLin, nbCol, board);

		territoriesPlayer1 = getNumberOfTerritoriesForPlayer(nbLin, nbCol, board, 1);
		territoriesPlayer2 = getNumberOfTerritoriesForPlayer(nbLin, nbCol, board, 2);

		printf("\nTerritories Player 1: %d - Territories Player 2: %d\n", territoriesPlayer1, territoriesPlayer2);
		lastTurn--;
		numPlayer++;
		if (numPlayer > 2){
			numPlayer = 1;
		}
	}
	if (territoriesPlayer1 > territoriesPlayer2){
		winner = 1;
	}
	else if (territoriesPlayer2 > territoriesPlayer1){
		winner = 2;
	}
	return winner;
}

int main(){
	int board[NBLIN][NBCOL];
	int winner;

	srand(time(NULL));
	initArray(NBLIN, NBCOL, board, 0);
	showBoard(NBLIN, NBCOL, board);
	winner = runGame(NBLIN, NBCOL, board);
	endOfGame(winner);

	return 0;
}