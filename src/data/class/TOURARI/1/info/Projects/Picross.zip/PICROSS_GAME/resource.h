/*
TOURARI Jérémy
BARREIRA Nina
*/

int L, C;

int getMaxValSeries(int size, int TAB_player[]);
void getSize(int nbLin, int nbCol, int seqLin[], int seqCol[], int size[]);
int pickAValue(int size);
int getAnInteger();
int getAValue();
void showColumn(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]);
void initiateTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]);
void upgradeTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]);
void fillRandom(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]);
void fillPicture(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], FILE *level);
int getSeqH(int nbLin, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]);
int getSeqV(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]);
void getSeqLinCol(int nbLin, int nbCol, int TAB_complete[nbLin][nbCol], int seqLin[], int seqCol[]);
void getNbBlackCaseH(int nbLin, int NBLIN,  int NBCOL, int TAB_player[NBLIN][NBCOL], int seq, int blackCase[]);
void getNbBlackCaseV(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int seq, int blackCase[]);
void getNbBlackCaseLinCol(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int seqLin[], int seqCol[], int blackCaseLin[nbLin][nbCol], int blackCaseCol[nbLin][nbCol]);
void showTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]);
void copyArray(int nbLin, int nbCol, int array1[nbLin][nbCol], int array2[nbLin][nbCol]);
void setBackground();
void drawArray(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int size[]);
void getInformation(int start_Y, int start_X, int height, int width, int nbLin, int nbCol);
void putValue(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int size[]);
void setWhiteCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]);
void setBlackCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]);
void setCrossCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]);
int checkCol(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int TAB_complete[NBLIN][NBCOL]);
int checkLin(int nbLin, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int TAB_complete[NBLIN][NBCOL]);
void fillTAB_Player(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]);
void validateLinCol(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int start_Y, int start_X, int size[]);
int testGameOver(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]);
void initiateRandomGame(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]);
void initiatePictureGame(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], FILE *level);
void showBOARD(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int start_Y, int start_X, int size[]);
void showResult(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]);
void printTitle(FILE *title, int start_y, int start_x, int center);
void exitGame();
void mute();
void muteAll(WINDOW *sound);
void showHelp();
void soundON();
void soundOFF();
void crackResult(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]);
void runGame(int start_Y, int start_X, int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int coord_Y, int coord_X, int size[]);

//Loading Menu
void continueGame();
void *getConfirmation(void *arg);
void loadingBar();
void loadingMenu();

//MOUSE CLICK
void ncurses_initialiser();
void ncurses_couleurs();
void ncurses_souris();
int click_souris();
char key_pressed();
void LANCEMENT_JEU();

//Set Sound Game
void *put_soundtrackOpening(void *arg);
void *put_soundCase(void *arg);
void *put_soundYes(void *arg);
void *put_soundNo(void *arg);
void *put_soundNavigateMenu(void *arg);
void *put_soundValidateGame(void *arg);
