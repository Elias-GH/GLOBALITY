#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>

#include "gameFonction.h"
#include "resource.h"

/*
TOURARI Jérémy
BARREIRA Nina
*/

/*
Program needs sox
Program needs ncurses
Program needs thread

Need to install :
  - sudo apt install gcc
  - sudo apt install sox
  - sudo apt-get install libncurses*
  - sudo apt install libsox-fmt-all
  - sudo apt install libpthread*
*/


int main(){
     sleep(1);
 	//Initialisation de ncurses, de la souris et de la couleur
 	ncurses_initialiser(); 	//Initialisation de ncurses
	ncurses_souris(); 		//Initialisation de la souris
	ncurses_couleurs();		//Initialise les couleurs
	soundON();			//Initialise les son

	int numberGame = 1;   //variable pour le choix du jeu
	int nbLin, nbCol;     //Nb demandé de ligne et Nb de colonnes
	int restart;          //variable pour rester dans la boucle while
 	pthread_t soundtrack; //déclaration thread pour musique démarrage

//////////////////// HELLO //////////////////
    //refresh();
    clear();
    setBackground();
    attron(COLOR_PAIR(4));
    mvprintw(LINES/2, COLS/2 - 5, "Welcome to");
    attroff(COLOR_PAIR(4));
    pthread_create(&soundtrack, NULL, put_soundtrackOpening, NULL);  //Lancement de la musique
    refresh();
    sleep(3);
    clear();

///////////// CORP DU JEU //////////////////
	while(numberGame != 0){                        //number game initialisé à 1, pour rentrer dans le while
		numberGame = startMenu();                    //récupère le choix du jeu

		if (numberGame == 1){
			nbLin = 5;                                 //Initialisation de nbCol et nbLin en fonction de la difficulté
			nbCol = 5;
			clear();
			restart = randomGame(nbLin, nbCol);        //Récupère la valeur restart pour recommencer le jeu
			while (restart == 1){
				restart = randomGame(nbLin, nbCol);
			}
		}
		if (numberGame == 2){
			nbLin = 10;
			nbCol = 10;
			clear();
			restart = randomGame(nbLin, nbCol);
			while (restart == 1){
				restart = randomGame(nbLin, nbCol);
			}
		}
		if (numberGame == 3){
			nbLin = 15;
			nbCol = 15;
			clear();
			restart = randomGame(nbLin, nbCol);
			while (restart == 1){
				restart = randomGame(nbLin, nbCol);
			}
		}
		if (numberGame == 4){                                   //Mode personnalisé
			getDim(&nbLin, &nbCol);
			clear();
			restart = randomGame(nbLin, nbCol);
			while (restart == 1){
				restart = randomGame(nbLin, nbCol);
			}
		}
		if (numberGame == 5){
			clear();
               restart = pictureGame(1);
			while (restart == 1){
				restart = pictureGame(1);
			}
		}
		if (numberGame == 6){
			clear();
               restart = pictureGame(2);
			while (restart == 1){
				restart = pictureGame(2);
			}
		}
		if (numberGame == 7){
			clear();
               restart = pictureGame(3);
			while (restart == 1){
				restart = pictureGame(3);
			}
		}
		if (numberGame == 8){
			clear();
               restart = pictureGame(4);
               while (restart == 1){
                    restart = pictureGame(4);
               }
		}
		if (numberGame == 9){
			clear();
               restart = pictureGame(5);
			while (restart == 1){
				restart = pictureGame(5);
			}
		}
          if (numberGame == 10){
			clear();
               restart = pictureGame(6);
			while (restart == 1){
				restart = pictureGame(6);
			}
		}
	}
	soundON();	//réctivation du son pour le prochain lancement de jeu

//////////////////////////// END GAME //////////////////////
	clear();
	attron(COLOR_PAIR(4));
	mvprintw(LINES/2, COLS/2 - 10, "Press any key to exit");
	attroff(COLOR_PAIR(4));
	refresh();
	getch();	//En attente d'une touche pour confirmer la sortie du jeu
	clear();
	setBackground();
	attron(COLOR_PAIR(4));
	mvprintw(LINES/2, COLS/2 - 4, "Goodbye");
	attroff(COLOR_PAIR(4));
	refresh();
	system("play -q 'sound/soundExit_ON.mp3' repeat 0 >/dev/null 2>&1");
	endwin();

	return 0;
}
