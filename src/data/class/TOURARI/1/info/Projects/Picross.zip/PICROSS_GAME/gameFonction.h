/*
TOURARI Jérémy
BARREIRA Nina
*/

//StartMenu
void putTitlePICROSS();
void showModeRandom(WINDOW *random, int height, int width, int start_Y, int start_X);
void showLevelRandom(WINDOW *random, int height, int width, int start_Y, int start_X);
void showModePicture(WINDOW *picture, int height, int width, int start_Y, int start_X);
void showLevelPicture(WINDOW *picture, int height, int width, int start_Y, int start_X);
void showInformation();
void showAuthorBox();
void showHelpMenu();
int startMenu();

//PICROSS GAME MODE
int pictureGame(int level);
int randomGame(int nbLin, int nbCol);

//CustomRandom
void infoMax();
void boxNbLinNbCol();
int askBoxNbLin();
int askBoxNbCol();
void boxNbLinValidate(int nbLin);
void boxNbColValidate(int nbCol);
void middleDrawLine();
void getDim(int *p_lin, int *p_col);

//GameOver
void showYesButton();
void showNoButton();
void setSeparationRestart();
int setGameOver(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]);
