#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>

#include "gameFonction.h"
#include "resource.h"

/*
TOURARI Jérémy
BARREIRA Nina
*/

//////////////////////////////////////////////////////////////////////////////////////////

////////////////////			FONCTION GLOBAL		//////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
int getMaxValSeries(int size, int TAB_player[]){
	int max = TAB_player[0];
	int i;
	for (i = 0; i < size; i++){
		if (max < TAB_player[i]){
			max = TAB_player[i];
		}
	}
	return max;
}

void getSize(int nbLin, int nbCol, int seqLin[], int seqCol[], int size[]){
	/*int maxSizeLin = getMaxValSeries(nbLin, seqLin);
	int maxSizeCol = getMaxValSeries(nbCol, seqCol);

	size[0] = maxSizeLin;
	size[1] = (LINES - maxSizeCol - 2)/nbLin;
	size[2] = (COLS hg- 3*maxSizeLijhn - 4)/nbCol;
	size[3] = maxSizeCol;*/
	if (nbLin > 5 || nbCol > 5){
		size[0] = nbCol + 4;
		size[3] = nbLin/2;
		size[1] = (LINES - size[3])/nbLin;
		size[2] = 2*size[1];

		if (size[0] < 20){
			size[0] = 20;
		}
		if (size[3] < LINES/4){
			size[3] = LINES/4;
		}

		while ((nbLin*size[1]) + size[3] > LINES - 2){
			size[1]--;
		}
		while ((nbCol*size[2]) + size[0] > COLS - 4) {
			size[2]--;
		}

		if (size[1] > size[2]/2){
			size[1] = size[2]/2;
			if (size[1] < 2) size[1] = 2;
		}
		if (size[2] > size[1]*2){
			size[2] = size[1]*2;
			if (size[2] < 3) size[2] = 3;
		}
	}
	else {
		size[0] = ((2*COLS)/(2+nbCol))/2 + 4;
		size[1] = (LINES/(2+nbLin))/2 + 2;
		size[2] = 2*size[1];
		size[3] = size[0]/2;
		/*if (size[1] < 2){
			size[1] = 2;
			size[2] = 2*size[1];
		}
		if (size[2] < 3){
			size[2] = 3;
			size[1] = size[2]/2;
		}*/
	}
}

int pickAValue(int size){
	int val;
	val = rand()%size;

	return val;
}

int getAnInteger(){
	int enter = -1;
	while(enter < 0){
		if (scanf("%d", &enter) != 1){
			printf("Input Error\n");
			exit(-1);
		}
	}
	return enter;
}

int getAValue(){
	int enter = -1;
	while (enter < 0){
		if (scanf("%d", &enter) != 1){
			printf("Input Error\n");
			exit(-1);
		}
	}
	return enter;
}

void showColumn(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]){
	for (int i = 0; i < NBLIN; i++){
		printf("TAB_player(%d, %d) : %d\n", i, nbCol, TAB_player[i][nbCol]);
	}
}

void initiateTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]){
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			TAB_player[i][j] = 0;
		}
	}
}

void upgradeTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]){
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (TAB_player[i][j] == 0){
				TAB_player[i][j] = 2;
			}
		}
	}
}

void fillRandom(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]){
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			TAB_player[i][j] = pickAValue(2);
		}
	}
}

void fillPicture(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], FILE *level){
	int i = 0;
	int j = 0;
	fseek(level, 6, SEEK_SET);
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			fscanf(level, "%d", &TAB_player[i][j]);
			mvprintw(5 + i, 5 + j, "%d", TAB_player[i][j]);
		}
	}
	fclose(level);
}

int getSeqH(int nbLin, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]){
	int seq = 0;
	int cpt = 0;
	int i;
	for (i = 0; i < NBCOL-1; i++){
		if (TAB_player[nbLin][i] == 1){
			seq++;
		}
		if (TAB_player[nbLin][i] == TAB_player[nbLin][i+1] && TAB_player[nbLin][i] == 1){
			cpt++;
		}
	}
	if (TAB_player[nbLin][NBCOL-1] == 1) seq++;
	return seq-cpt;
}

int getSeqV(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL]){
	int seq = 0;
	int cpt = 0;
	int i;
	for (i = 0; i < NBLIN-1; i++){
		if (TAB_player[i][nbCol] == 1){
			seq++;
		}
		if (TAB_player[i][nbCol] == TAB_player[i+1][nbCol] && TAB_player[i][nbCol] == 1){
			cpt++;
		}
	}
	if (TAB_player[NBLIN-1][nbCol] == 1) seq++;
	return seq-cpt;
}

void getSeqLinCol(int nbLin, int nbCol, int TAB_complete[nbLin][nbCol], int seqLin[], int seqCol[]){
	int i;

	for (i = 0; i < nbLin; i++){
		seqLin[i] = getSeqH(i, nbLin, nbCol, TAB_complete);
	}

	for (i = 0; i < nbCol; i++){
		seqCol[i] = getSeqV(i, nbLin, nbCol, TAB_complete);
	}
}

void getNbBlackCaseH(int nbLin, int NBLIN,  int NBCOL, int TAB_player[NBLIN][NBCOL], int seq, int blackCase[]){
	int i = 0;
	int j;

	////////// INITIALISATION DES COMPTEURS DE CASES NOIRES (=1) //////////////////////
	for (i = 0; i < seq; i++){
		blackCase[i] = 0;
	}

	////////////// COMPTEUR DE CASE NOIRES QUAND LE TABLEAU COMMENCE PAR UN 1 OU 0 //////////
	if (TAB_player[nbLin][0] == 1) j = 0;
	if (TAB_player[nbLin][0] == 0) j = -1;

	for (i = 0; i < NBCOL; i++){
		if (TAB_player[nbLin][i] == 1){
			blackCase[j]++;
		}
		if (TAB_player[nbLin][i] == 0 && TAB_player[nbLin][i+1] == 1){
			j++;
		}
	}
}

void getNbBlackCaseV(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int seq, int blackCase[]){
	int i = 0;
	int j;

	////////// INITIALISATION DES COMPTEURS DE CASES NOIRES (=1) //////////////////////
	for (i = 0; i < seq; i++){
		blackCase[i] = 0;
	}

	////////////// COMPTEUR DE CASE NOIRES QUAND LE TABLEAU COMMENCE PAR UN 1 //////////
	if (TAB_player[0][nbCol] == 1) j = 0;
	if (TAB_player[0][nbCol] == 0) j = -1;

	for (i = 0; i < NBLIN; i++){
		if (TAB_player[i][nbCol] == 1){
			blackCase[j]++;
		}
		if (TAB_player[i][nbCol] == 0 && TAB_player[i+1][nbCol] == 1){
			j++;
		}
	}
}

void getNbBlackCaseLinCol(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int seqLin[], int seqCol[], int blackCaseLin[nbLin][nbCol], int blackCaseCol[nbLin][nbCol]){
	int i;

	for (i = 0; i < nbLin; i++){
		getNbBlackCaseH(i, nbLin, nbCol, TAB_player, seqCol[i], blackCaseCol[i]);
	}
	for (i = 0; i < nbCol; i++){
		getNbBlackCaseV(i, nbLin, nbCol, TAB_player, seqLin[i], blackCaseLin[i]);
	}
}

void showTAB(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]){
	int i, j;
	int seqH = 0;
	int seqV = 0;

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			printf("%3d", TAB_player[i][j]);
		}
		seqH = getSeqH(i, nbLin, nbCol, TAB_player);
		int blackCaseH[seqH];
		getNbBlackCaseH(i, nbLin, nbCol, TAB_player, seqH, blackCaseH);
		printf(" | %d -- ", seqH);
		for (j = 0; j < seqH; j++){
			printf("%d ", blackCaseH[j]);
		}
		printf("\n");
	}
	printf("\n");
	for (i = 0; i < nbCol; i++){
		printf("---");
	}
	printf("\n");

	for (i = 0; i < nbCol; i++){
		printf("Colonne %d : \n", i);
		showColumn(i, nbLin, nbCol, TAB_player);
		seqV = getSeqV(i, nbLin, nbCol, TAB_player);
		printf("\tSeq Col %d : %d -- ", i, seqV);
		int blackCaseV[seqV];
		getNbBlackCaseV(i, nbLin, nbCol, TAB_player, seqV, blackCaseV);
		for (j = 0; j < seqV; j++){
			printf("%d ", blackCaseV[j]);
		}
		printf("\n");
	}
	printf("\n");
}

void copyArray(int nbLin, int nbCol, int array1[nbLin][nbCol], int array2[nbLin][nbCol]){	 //sauvegarde des données
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			array2[i][j] = array1[i][j];
		}
	}
}

void setBackground(){
	int i, j;
	attron(COLOR_PAIR(4));
	for (i = 0; i < LINES; i++){
		for (j = 0; j < COLS; j++){
			//i%3 == 1 gestion de la position des points sur l'axe des lignes
			//i%3 == 2 gestion de la position des points sur l'axe des colonnes
			attron(COLOR_PAIR(23));
			if (i%3 == 1 && j%6 == 2) mvaddch(i, j, '.');
			attroff(COLOR_PAIR(23));
		}
	}
	attroff(COLOR_PAIR(4));
}

void drawArray(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int size[]){
	int i, j, k;

	///////////////////// PARAMÈTRE ///////////////////

	int widthLeftColFix = size[0];	//Largeur des lignes fixes de gauche
	int heightLeftColFix = size[1];	//Hauteur des lignes fixes de gauche

	int widthTopColFix = size[2];	//Largeur des colonnes fixes d'en haut
	int heightTopColFix = size[3];	//Hauteur des colonnes fixes d'en haut

	int start_Y = LINES/2 - (nbLin*heightLeftColFix + heightTopColFix)/2;			//position reference Y pour la création du tableau
	int start_X = COLS/2 - (nbCol*widthTopColFix + widthLeftColFix)/2;			//position reference X pour la création du tableau

	////////////////// CORPS DU TABLEAU ///////////////////
	attron(COLOR_PAIR(4));
	//Tracer Horizontal
	for (i = 0; i < nbLin; i++){
		move(start_Y + heightTopColFix + (i+1)*heightLeftColFix, start_X + widthLeftColFix + 1);
		for (j = 0; j < nbCol*widthTopColFix; j++){
			addch(ACS_HLINE);
		}
	}
	//Tracer Vertical
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			for (k = 0; k < (nbLin)*heightLeftColFix; k++){
				mvaddch(start_Y + k + heightTopColFix, 1 + start_X + widthLeftColFix + (j+1)*widthTopColFix, ACS_VLINE);
			}
		}
	}
	/////////////// DETAIL DU CORPS DU TABLEAU ////////////////////////
	for (i = 0; i < nbLin; i++){
		for (j = 0 ; j < nbCol; j++){
			move(start_Y + heightTopColFix + i * heightLeftColFix, start_X + widthLeftColFix + 1 + j * widthTopColFix);
			addch(ACS_PLUS);
			move(start_Y + heightTopColFix + i * heightLeftColFix, start_X + widthLeftColFix + 1 + nbCol * widthTopColFix);
			addch(ACS_RTEE);
			move(start_Y + heightTopColFix + nbLin*heightLeftColFix, start_X + 1 + widthLeftColFix + (j+1)*widthTopColFix);
			addch(ACS_BTEE);
			move(start_Y + heightTopColFix + nbLin*heightLeftColFix, start_X + 1 + widthLeftColFix + (nbCol*widthTopColFix));
			addch(ACS_LRCORNER);
		}
	}

	////////////// BASE DE GAUCHE POUR LE TABLEAU ///////////////
	for (j = 0; j < nbLin*heightLeftColFix; j++){
		mvaddch(start_Y + heightTopColFix + j, start_X, ACS_VLINE);
		mvaddch(start_Y + heightTopColFix + j, start_X + widthLeftColFix + 1, ACS_VLINE);
	}
	for (i = 0; i <= nbLin; i++){
		mvaddch(start_Y + heightTopColFix+1 + i * heightLeftColFix-1, start_X, ACS_LTEE);
		mvaddch(start_Y + heightTopColFix+1 + i * heightLeftColFix-1, start_X + widthLeftColFix + 1, ACS_PLUS);
		for (j = 0; j < widthLeftColFix; j++){
			mvaddch(start_Y + i*heightLeftColFix + heightTopColFix, 1 + start_X + j, ACS_HLINE);
		}
	}
	mvaddch(start_Y + heightTopColFix, start_X, ACS_ULCORNER);
	mvaddch(start_Y + heightTopColFix + nbLin * heightLeftColFix, start_X, ACS_LLCORNER);
	mvaddch(start_Y + heightTopColFix + nbLin * heightLeftColFix, 1 + start_X + widthLeftColFix, ACS_BTEE);

	///////////// BASE HAUTE POUR LE TABEAU ///////////////
	for (i = 0; i <= nbCol; i++){
		for (j = 0; j < heightTopColFix; j++){
			mvaddch(start_Y + j, 1 + start_X + widthLeftColFix, ACS_VLINE);
			mvaddch(start_Y + j, 1 + start_X + widthLeftColFix + i * widthTopColFix,ACS_VLINE);
		}
	}
	for (i = 0; i < nbCol * widthTopColFix; i++){
		mvaddch(start_Y, 1 + start_X + widthLeftColFix + i, ACS_HLINE);
		mvaddch(start_Y + heightTopColFix, 1 + start_X + widthLeftColFix + i, ACS_HLINE);
	}
	for (i = 0; i < nbCol; i++){
		mvaddch(start_Y, 1 + start_X + widthLeftColFix + i * widthTopColFix, ACS_TTEE);
		mvaddch(start_Y + heightTopColFix, 1 + start_X + widthLeftColFix + i * widthTopColFix, ACS_PLUS);
	}
	mvaddch(start_Y, 1 + start_X + widthLeftColFix, ACS_ULCORNER);
	mvaddch(start_Y, 1 + start_X + widthLeftColFix + nbCol * widthTopColFix, ACS_URCORNER);
	mvaddch(start_Y + heightTopColFix, 1 + start_X + widthLeftColFix, ACS_PLUS);
	mvaddch(start_Y + heightTopColFix, 1 + start_X + widthLeftColFix + nbCol * widthTopColFix, ACS_RTEE);
	attroff(COLOR_PAIR(4));
}

void getInformation(int start_Y, int start_X, int height, int width, int nbLin, int nbCol){
	int i, j;
	char easy[] = "easy  ";
	char normal[] = "normal";
	char hard[] = "hard  ";
	if (nbLin <= 5 || nbCol <= 5);
	if (nbLin <= 10 || nbCol <= 10);
	if (nbLin > 10 && nbCol > 10);

	attron(COLOR_PAIR(4));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
		}
	}
	if (height > 9 && width > 18){
		mvprintw(start_Y + 1, start_X + width/2 - 7, "PICROSS GAME :");
		mvprintw(start_Y + height/2 - 2, start_X + width/2 - 7, "LEVEL : ");
		attron(A_BOLD);
		if (nbLin <= 10 || nbCol <= 10) mvprintw(start_Y + height/2 - 2, start_X + width/2 + 1, "%s", normal);
		if (nbLin <= 5 || nbCol <= 5) mvprintw(start_Y + height/2 - 2, start_X + width/2 + 1, "%s", easy);
		if (nbLin > 10 && nbCol > 10) mvprintw(start_Y + height/2 - 2, start_X + width/2 + 1, "%s", hard);
		attroff(A_BOLD);
		mvprintw(start_Y + height/2, start_X + width/2 - 8, "Dimension %d x %d", nbLin, nbCol);
	}
	else {
		mvprintw(start_Y + height/2, start_X + width/2 - 4, "PICROSS");
	}
	attroff(COLOR_PAIR(4));
}

void putValue(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int size[]){
	int i, j, k;
	int seqH = 0;
	int seqV = 0;

	int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];
	int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];

	attroff(COLOR_PAIR(8));
	attron(COLOR_PAIR(18));
	for (i = 0; i < nbLin; i++){
		move(start_Y + (i)*size[1] + 1 - size[3], start_X - 2*size[0] + 1);
		for (j = 0; j < size[0]; j++){
			for (k = 0; k < size[1] - 1; k++){
				move(start_Y + (i)*size[1] + (k+1), start_X + (j+1) - size[0]);
				addch(ACS_CKBOARD);
			}
		}
	}

	for (i = 0; i < nbCol; i++){
		for (j = 1; j < size[2]; j++){
			for (k = 0; k < size[3] - 1; k++){
				move(start_Y - (k+1), start_X + size[2]*i + (j+1));
				addch(ACS_CKBOARD);
			}
		}
	}
	attroff(COLOR_PAIR(18));

	attron(COLOR_PAIR(19));
	for (i = 0; i < nbLin; i++){
		seqH = getSeqH(i, nbLin, nbCol, TAB_player);
		int blackCaseH[seqH];
		getNbBlackCaseH(i, nbLin, nbCol, TAB_player, seqH, blackCaseH);
		if (seqH == 0) mvaddch(start_Y + i*size[1] + size[1]/2, start_X - 1, '0');
		move(start_Y + (i)*size[1] + (size[1]/2), start_X - seqH*3);
		for (j = 0; j < seqH; j++){
			printw("%3d", blackCaseH[j]);
		}
	}
	attroff(COLOR_PAIR(19));

	//Correction pour eviter un dépassement de couleur du tableau
	attron(COLOR_PAIR(1));
	for (i = 1; i < 2; i++){
		for (j = 0; j < nbLin*size[1] - 1; j++){
			move(start_Y + j + 1, start_X - i - size[0]);
			addch(ACS_CKBOARD);
		}
	}
	attroff(COLOR_PAIR(1));

	attron(COLOR_PAIR(19));
	for (i = 0; i < nbCol; i++){
		seqV = getSeqV(i, nbLin, nbCol, TAB_player);
		int blackCaseV[seqV];
		getNbBlackCaseV(i, nbLin, nbCol, TAB_player, seqV, blackCaseV);
		if (seqV == 0) mvaddch(start_Y - 1, start_X + size[2]*(i+1) - size[2]/2, '0');
		for (j = 0; j < seqV; j++){
			move(start_Y - seqV + j, start_X + size[2]*(i+1) - size[2]/2);
			printw("%d", blackCaseV[j]);
		}
	}
	attroff(COLOR_PAIR(19));
}

void setWhiteCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]){
	int i, j;

	int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];
	int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];
	move(start_Y, start_X);

	for (i = 1; i < size[2]; i++){
		for (j = 1; j < size[1]; j++){
			mvaddch(start_Y + j + coord_Y * size[1], start_X + i + 1 + coord_X * size[2], ' ');
		}
	}
}

void setBlackCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]){
	int i, j;

	int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];
	int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];
	move(start_Y, start_X);

	attron(COLOR_PAIR(2));
	for (i = 1; i < size[2]; i++){
		for (j = 1; j < size[1]; j++){
			mvaddch(start_Y + j + coord_Y * size[1], start_X + i + 1 + coord_X * size[2], ACS_CKBOARD);
		}
	}
	attroff(COLOR_PAIR(2));
}

void setCrossCase(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]){
	int i, j;

	int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];
	int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];
	move(start_Y, start_X);

	attron(COLOR_PAIR(3));
	for (i = 1; i < size[2]; i++){
		for (j = 1; j < size[1]; j++){
			mvaddch(start_Y + j + coord_Y * size[1], start_X + i + 1 + coord_X * size[2], ACS_PLUS);
		}
	}
	attroff(COLOR_PAIR(3));
}

int checkCol(int nbCol, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int TAB_complete[NBLIN][NBCOL]){
	int i;
	int cptColPlayer = 0;

	for (i = 0; i < NBLIN; i++){
		if (TAB_complete[i][nbCol] == TAB_player[i][nbCol] && TAB_complete[i][nbCol] == 1){
			cptColPlayer++;
		}
		if (TAB_complete[i][nbCol] == 0 && TAB_player[i][nbCol] == 2){
			cptColPlayer++;
		}
	}
	if (NBLIN == cptColPlayer) return 1;
	else return 0;
}

int checkLin(int nbLin, int NBLIN, int NBCOL, int TAB_player[NBLIN][NBCOL], int TAB_complete[NBLIN][NBCOL]){
	int i;
	int cptLinPlayer = 0;
	for (i = 0; i < NBCOL; i++){
		if (TAB_complete[nbLin][i] == TAB_player[nbLin][i] && TAB_complete[nbLin][i] == 1){
			cptLinPlayer++;
		}
		if (TAB_complete[nbLin][i] == 0 && TAB_player[nbLin][i] == 2){
			cptLinPlayer++;
		}
	}
	if (NBCOL == cptLinPlayer) return 1;
	else return 0;
}

void fillTAB_Player(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int coord_Y, int coord_X, int size[]){
	int i, j;
	TAB_player[coord_Y][coord_X] = TAB_player[coord_Y][coord_X] + 1;
	TAB_player[coord_Y][coord_X] = TAB_player[coord_Y][coord_X] % 3;

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (TAB_player[i][j] == 0){
	    		setWhiteCase(nbLin, nbCol, TAB_player, i, j, size);
		    }
		    if (TAB_player[i][j] == 1){
		    	setBlackCase(nbLin, nbCol, TAB_player, i, j, size);
		    }
		    if (TAB_player[i][j] == 2){
		    	setCrossCase(nbLin, nbCol, TAB_player, i, j, size);
		    }
		}
	}
}

void validateLinCol(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int start_Y, int start_X, int size[]){
	int i, j, k;
	int checkColCpt[nbCol];
	int checkLinCpt[nbLin];

	for (i = 0; i < nbLin; i++){
		checkLinCpt[i] = checkLin(i, nbLin, nbCol, TAB_player, TAB_complete);
	}
	for (i = 0; i < nbCol; i++){
		checkColCpt[i] = checkCol(i, nbLin, nbCol, TAB_player, TAB_complete);
	}
	attron(COLOR_PAIR(17));
	for (i = 0; i < nbLin; i++){
		if (checkLinCpt[i] == 1){
			move(start_Y + (i)*size[1] + 1, start_X - size[0] + 1);
			for (j = 0; j < size[0]; j++){
				for (k = 0; k < size[1] - 1; k++){
					move(start_Y + (i)*size[1] + (k+1), start_X - size[0] + (j+1));
					addch(ACS_CKBOARD);
				}
			}
		}
	}

	for (i = 0; i < nbCol; i++){
		if (checkColCpt[i] == 1){
			for (j = 1; j < size[2]; j++){
				for (k = 0; k < size[3] - 1; k++){
					move(start_Y - (k+1), start_X + size[2]*i + (j+1));
					addch(ACS_CKBOARD);
				}
			}
		}
	}
	attroff(COLOR_PAIR(17));
	move(0, 0);
}

int testGameOver(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]){
	int i, j;
	int checkColCpt[nbCol];
	int checkLinCpt[nbLin];

	for (i = 0; i < nbLin; i++){
		checkLinCpt[i] = checkLin(i, nbLin, nbCol, TAB_player, TAB_complete);
	}
	for (i = 0; i < nbCol; i++){
		checkColCpt[i] = checkCol(i, nbLin, nbCol, TAB_player, TAB_complete);
	}

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (checkLinCpt[i] != 1 || checkColCpt[j] != 1) return 0;
		}
	}
	return 1;
}

void initiateRandomGame(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]){
	initiateTAB(nbLin, nbCol, TAB_player);			//initialisation de TAB_player à 0
	initiateTAB(nbLin, nbCol, TAB_complete);		//initialisation de TAB_complete à 0
	fillRandom(nbLin, nbCol, TAB_complete);		//remplie le TAB avec des vals
}

void initiatePictureGame(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], FILE *level){
	initiateTAB(nbLin, nbCol, TAB_player);			//initialisation de TAB_player à 0
	initiateTAB(nbLin, nbCol, TAB_complete);		//initialisation de TAB_complete à 0
	fillPicture(nbLin, nbCol, TAB_complete, level);		//remplie le TAB avec des vals aléatoires
}

void showBOARD(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int start_Y, int start_X, int size[]){
	start_Y = LINES/2 - (nbLin*size[1] + size[3])/2;
	start_X = COLS/2 - (nbCol*size[2] + size[0])/2;
	int maxValLINES = start_Y + size[3] + nbLin*size[1];
	int maxValCOLS = start_X + size[0] + nbCol*size[2];

	if ((maxValLINES >= LINES || maxValCOLS >= COLS) || (size[1] < 2 || size[2] < 3)){
		clear();
		attron(COLOR_PAIR(4));
		mvprintw(LINES/2, COLS/2 - 12, "Please, resize your window");
		mvprintw(LINES/2 + 1, COLS/2 - 16, "Then click anywhere on the screen");
		attroff(COLOR_PAIR(4));
	}
	else {
	    	getInformation(start_Y, start_X, size[3], size[0], nbLin, nbCol);	//Avoir les info du tableau
	    	putValue(nbLin, nbCol, TAB_complete, size);	//ajouter valeur de lignes et colonnes
	    	drawArray(nbLin, nbCol, TAB_player, size);			//Dessiner Tableau
	}
}

void showResult(int nbLin, int nbCol, int TAB_player[nbLin][nbCol]){
	int i, j;
	int size[4];

	size[0] = 5;
	size[1] = 2;
	size[2] = size[1]*2;
	size[3] = 2;

    drawArray(nbLin, nbCol, TAB_player, size);			//Dessiner Tableau

    for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
		    if (TAB_player[i][j] == 1){
		    	setBlackCase(nbLin, nbCol, TAB_player, i, j, size);
		    }
		    if (TAB_player[i][j] == 0){
		    	setCrossCase(nbLin, nbCol, TAB_player, i, j, size);
		    }
		}
	}
}

void printTitle(FILE *title, int start_y, int start_x, int center){
     int i, j;
     int cpt = 0;
     int cptMax = 0;
     int charTitle;
     while ((charTitle = fgetc(title)) != EOF){
		cpt++;
		if (cptMax < cpt){
			cptMax = cpt;
		}
		if (charTitle == '\n'){
               cpt = 0;
          }
     }
     if (center == 1) start_x = start_x/2 - cptMax/2;
     i = start_y;
     j = start_x;
     fseek(title, 0, SEEK_SET);
     while ((charTitle = fgetc(title)) != EOF){
          mvaddch(i, j, charTitle);
          j++;
          if (charTitle == '\n'){
               i++;
               j = start_x;
          }

     }
     fclose(title);
}

void exitGame(){
	int i, j;
	int start_Y = 0;
	int start_X = 0;
	int width = 10;
	int height = 5;

	attron(COLOR_PAIR(8));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			mvaddch(start_Y + i, start_X + j, ACS_CKBOARD);
		}
	}
	attroff(COLOR_PAIR(8));
	attron(COLOR_PAIR(9));
	mvprintw(start_Y + height/2, start_X + width/2 - 2, "EXIT");
	attroff(COLOR_PAIR(9));
}

void mute(){
	int width = 10;
	int height = 3;
	int stateGLB = -1;
	int stateLOC = -1;
	WINDOW *soundGLB;
	WINDOW *soundLOC;
	soundGLB = subwin(stdscr, height, width/2, 5, 0);
	soundLOC = subwin(stdscr, height, width/2, 5, width/2);
	if (fopen("sound/fileTEST_OFF.mp3", "r") == NULL)stateGLB = 1;
	if (fopen("sound/fileTEST_ON.mp3", "r") == NULL)stateGLB = 2;

	if (fopen("sound/soundCase_OFF.mp3", "r") == NULL)stateLOC = 1;
	if (fopen("sound/soundCase_ON.mp3", "r") == NULL)stateLOC = 2;

	if (stateLOC == 1){
		wbkgd(soundLOC, COLOR_PAIR(6));
		wattron(soundLOC, COLOR_PAIR(7));
		mvwprintw(soundLOC, 1, width/2 - 4, "LOC");
		wattroff(soundLOC, COLOR_PAIR(7));
		wrefresh(soundLOC);
	}
	if (stateLOC == 2){
		wbkgd(soundLOC, COLOR_PAIR(8));
		wattron(soundLOC, COLOR_PAIR(9));
		mvwprintw(soundLOC, 1, width/2 - 4, "LOC");
		wattroff(soundLOC, COLOR_PAIR(9));
		wrefresh(soundLOC);
	}
	if (stateLOC == -1){
		wattron(soundLOC, COLOR_PAIR(9));
		mvwprintw(soundLOC, height/4, width/2 - 3, "FAIL");
		wattroff(soundLOC, COLOR_PAIR(9));
		wrefresh(soundLOC);
	}

	if (stateGLB == 1){
		wbkgd(soundGLB, COLOR_PAIR(6));
		wattron(soundGLB, COLOR_PAIR(7));
		mvwprintw(soundGLB, 1, width/2 - 4, "GLB");
		wattroff(soundGLB, COLOR_PAIR(7));
		wrefresh(soundGLB);
	}
	if (stateGLB == 2){
		wbkgd(soundGLB, COLOR_PAIR(8));
		wattron(soundGLB, COLOR_PAIR(9));
		mvwprintw(soundGLB, 1, width/2 - 4, "GLB");
		wattroff(soundGLB, COLOR_PAIR(9));
		wrefresh(soundGLB);
	}
	if (stateGLB == -1){
		wattron(soundGLB, COLOR_PAIR(9));
		mvwprintw(soundGLB, height/4, width/2 - 3, "FAIL");
		wattroff(soundGLB, COLOR_PAIR(9));
		wrefresh(soundGLB);
	}
	delwin(soundGLB);
	delwin(soundLOC);
}

void muteAll(WINDOW *sound){
	int width = 10;
	int height = 3;
	int alreadyExist = -1;
	if (fopen("sound/fileTEST_OFF.mp3", "r") == NULL) alreadyExist = 1;
	if (fopen("sound/fileTEST_ON.mp3", "r") == NULL) alreadyExist = 2;

	if (alreadyExist == 1){
		wbkgd(sound, COLOR_PAIR(6));
		wattron(sound, COLOR_PAIR(7));
		mvwprintw(sound, 1, width/2 - 5, "SOUND GLB");
		wattroff(sound, COLOR_PAIR(7));
	}

	if (alreadyExist == 2){
		wbkgd(sound, COLOR_PAIR(8));
		wattron(sound, COLOR_PAIR(9));
		mvwprintw(sound, 1, width/2 - 5, "SOUND GLB");
		wattroff(sound, COLOR_PAIR(9));
	}
	if (alreadyExist == -1){
		wattron(sound, COLOR_PAIR(9));
		mvwprintw(sound, height/4, width/2 - 3, "FAIL");
		wattroff(sound, COLOR_PAIR(9));
	}
	wrefresh(sound);
	refresh();
}

void showHelp(){
	int dimText_Width = 14;
	int dimText_Height = 7;
	int start_Y = 0;
	int start_X = COLS - dimText_Width - 2;
	char charTitle;
	int i = 1;
	int j = 1;
	WINDOW *helpBox;
	FILE *file;
	file = fopen("text/help.txt", "r");

	helpBox = subwin(stdscr, dimText_Height + 2, dimText_Width + 2, start_Y, start_X);
	wbkgd(helpBox, COLOR_PAIR(24));

	while((charTitle = fgetc(file)) != EOF) {	//Écrit le titre
		wattron(helpBox, COLOR_PAIR(25));
		mvwprintw(helpBox, i, j, "%c",charTitle);
		wattroff(helpBox, COLOR_PAIR(25));
		j++;
		if (j >= 11){
			j = 0;
			i++;;
		}
	}

	wrefresh(helpBox);	//Rafraichi pour afficher le résultat
	refresh();
	fclose(file);
	delwin(helpBox);
}

void soundON(){
	system("mv sound/fileTEST_OFF.mp3 sound/fileTEST_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundCase_OFF.mp3 sound/soundCase_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundExit_OFF.mp3 sound/soundExit_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundGameOver_OFF.mp3 sound/soundGameOver_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundKick_OFF.mp3 sound/soundKick_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundNavigate_OFF.mp3 sound/soundNavigate_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundNo_OFF.mp3 sound/soundNo_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundValidate_OFF.mp3 sound/soundValidate_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundWelcomeTo_OFF.mp3 sound/soundWelcomeTo_ON.mp3 >/dev/null 2>&1");
	system("mv sound/soundYes_OFF.mp3 sound/soundYes_ON.mp3 >/dev/null 2>&1");
}

void soundOFF(){
	system("mv sound/fileTEST_ON.mp3 sound/fileTEST_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundCase_ON.mp3 sound/soundCase_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundExit_ON.mp3 sound/soundExit_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundGameOver_ON.mp3 sound/soundGameOver_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundKick_ON.mp3 sound/soundKick_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundNavigate_ON.mp3 sound/soundNavigate_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundNo_ON.mp3 sound/soundNo_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundValidate_ON.mp3 sound/soundValidate_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundWelcomeTo_ON.mp3 sound/soundWelcomeTo_OFF.mp3 >/dev/null 2>&1");
	system("mv sound/soundYes_ON.mp3 sound/soundYes_OFF.mp3 >/dev/null 2>&1");
}

void crackResult(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]){
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			TAB_complete[i][j] = TAB_player[i][j];
			if (TAB_player[i][j] == 0){
				TAB_complete[i][j] = 2;
			}
		}
	}
}

void runGame(int start_Y, int start_X, int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol], int coord_Y, int coord_X, int size[]){
	int testWin;		//test de sortie de jeu
	int oldSizeLin = LINES;	//pour le redimensionnement de la taille du terminal
	int oldSizeCol = COLS;	//pour le redimensionnement de la taille du terminal
	int soundTestGLB = 1;	//gestion du son global
	int soundTestLOC = 1;	//gestion du son local
	int seqLin[nbCol];		//Nb de séquence pour les lignes
	int seqCol[nbLin];		//Nb de séquence pour les colonnes
	pthread_t soundCase;	//Son d'une case
	pthread_t navigateMenu;	//Son de navigation
	pthread_t yes;			//Son de confirmation

	while (click_souris() == 0){
		if ((oldSizeLin != LINES) || (oldSizeCol != COLS)){	//Redimensionnement du terminal si changement de taille
			clear();
			refresh();
			getSeqLinCol(nbLin, nbCol, TAB_complete, seqLin, seqCol);	//Actualisation du nombre de séquence
			getSize(nbLin, nbCol, seqLin, seqCol, size);				//Actualisation de la taille du tableau
		}
		oldSizeLin = LINES;	//Actualisation de la taille du terminal
		oldSizeCol = COLS;	//Actualisation de la taille du terminal
		start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];	//Actualisation du point de départ du tableau
		start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];	//Actualisation du point de départ du tableau

		if ((L > start_Y && L < (start_Y + nbLin*size[1])) && (C > start_X && C < (start_X + nbCol*size[2]))){
	  		coord_X = (C - start_X) / size[2];	//C = SX + coord_X * size[2]
	   		coord_Y = (L - start_Y) / size[1];	//L = SY + coord_Y * size[1]
			pthread_create(&soundCase, NULL, put_soundCase, NULL);  //son de jeu avec les cases
			fillTAB_Player(nbLin, nbCol, TAB_player, coord_Y, coord_X, size);
	 	}
		if ((L >= 0 && L < 5) && (C >= 0 && C <= 10)){	//Bouton exit
			pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
			clear();
			break;
	 	}
	 	if ((L > 5 && L <= 8) && (C >= 0 && C < 5)){	//sound GLB on
		 soundTestGLB++;
		 soundTestGLB = soundTestGLB%2;
		 pthread_create(&yes, NULL, put_soundYes, NULL);
		 if (soundTestGLB == 1) soundON();
		 if (soundTestGLB == 0) soundOFF();
	  	}
		if ((L > 5 && L <= 8) && (C > 5 && C < 10)){	//sound LOC on
		 	soundTestLOC++;
		 	soundTestLOC = soundTestLOC%2;
		 	pthread_create(&yes, NULL, put_soundYes, NULL);
			if (soundTestLOC == 1) system("mv sound/soundCase_OFF.mp3 sound/soundCase_ON.mp3 >/dev/null 2>&1");
			if (soundTestLOC == 0) system("mv sound/soundCase_ON.mp3 sound/soundCase_OFF.mp3 >/dev/null 2>&1");
	  	}
	  	showBOARD(nbLin, nbCol, TAB_player, TAB_complete, start_Y, start_X, size);
		validateLinCol(nbLin, nbCol, TAB_player, TAB_complete, start_Y, start_X, size);	//Test de vérification
		exitGame();
		mute();
		refresh();
		//crackResult(nbLin, nbCol, TAB_complete, TAB);	//crack le résultat pour les tests
		testWin = testGameOver(nbLin, nbCol, TAB_player, TAB_complete);		//Test de fin de jeu
		if (testWin == 1){	//Si fin de jeu confirmer alors on sort de la partie
			system("play -q 'sound/soundGameOver_ON.mp3' repeat 0 >/dev/null 2>&1");
			break;
		}
	}
}

///////////////////////////////////////////////////////////////////////////

///////////////////////				LOADING MENU			///////////////////////////

///////////////////////////////////////////////////////////////////////////
void continueGame(){	//Phrase qui clignote
	int start_x = 1;
	int start_y = LINES - 5;

	attron(COLOR_PAIR(17) | A_BOLD);
	mvprintw(start_y, start_x + 10, "Click anywhere to start game...");
	attroff(COLOR_PAIR(17) | A_BOLD);
	refresh();
	usleep(750000);

	attron(COLOR_PAIR(4));
	mvprintw(start_y, start_x + 10, "                               ");
	attroff(COLOR_PAIR(4));
	refresh();
	usleep(250000);

	attron(COLOR_PAIR(17) | A_BOLD);
	mvprintw(start_y, start_x + 10, "Click anywhere to start game...");
	attroff(COLOR_PAIR(17) | A_BOLD);
	refresh();
}

void *getConfirmation(void *arg){	//Fonction qui récupère un caractère du clavier pour sortir du loadingMode
	int *valeur = (int *) arg;

	*valeur = getch();

	(void) arg;
	pthread_exit(NULL);
}

void loadingBar(){
	int i, j;
	int timer = 10000;			//timer de référence pour le temps de chargement

	int enter = 0;				//variable qui stocke le nouvelle état du clavier
	int *p_enter = &enter;		//pointeur liée à la variable enter

	int start_x = 1;			//point de référence en X
	int start_y = LINES - 5;	//point de référence en Y
	double bar = COLS-15;		//longeur de la barre de chargement

	double progress = 0.0;		//Valeur (en %) de la progression du chargement
	char pourcentage = '%';

	pthread_t yes;				//thread pour le son yes
	pthread_t confirm;			//thread pour la confirmation du chargement


	attron(COLOR_PAIR(4));
	//////////////////// CLEAN SPACE //////////////////
	for (i = start_y - 2; i < LINES; i++){
		for (j = 0; j < COLS; j++){
			mvprintw(i, j, " ");
		}
	}

	///////////////////// DRAW HLINE //////////////////
	move(start_y - 2, 0);
	for (i = 0; i < COLS; i++){
		addch(ACS_HLINE);
	}

	////////// INITIALISATION BARRE //////////////////
	mvprintw(start_y, start_x, "LOADING :");
	mvprintw(start_y + 2, start_x, "%3.0lf %c :", pourcentage, progress);
	mvaddch(start_y + 2, start_x + 7, ACS_VLINE);
	move(start_y + 2, start_x + 8);
	for (i = 0; i < COLS-14; i++){
		attron(COLOR_PAIR(20));
		addch(ACS_CKBOARD);
		attroff(COLOR_PAIR(20));
	}
	attron(COLOR_PAIR(4));
	addch(ACS_VLINE);
	attroff(COLOR_PAIR(4));
	refresh();

	///////////// PROGRESS BARRE //////////////////
	for (i = 0; i < COLS-14; i++){
		attron(COLOR_PAIR(4));
		mvprintw(start_y + 2, start_x, "%3.0lf %c :", pourcentage, progress);
		attroff(COLOR_PAIR(4));
		attron(COLOR_PAIR(17));
		mvaddch(start_y + 2, start_x + 8 + i, ACS_CKBOARD);
		usleep((100/bar)*timer);
		progress = progress + 100/bar;
		refresh();
		attroff(COLOR_PAIR(17));
	}
	pthread_create(&yes, NULL, put_soundYes, NULL);

///////////////////////////////// ATTENTION //////////////////////////////
	/// Nous plaçons le thread hors de la boucle while pour éviter un  ///
	/// problème de mémoire. En effet, le getch() peut rester dans le  ///
	/// while et cela créer un conflit avec le getch()                 ///
	//////////////////////////////////////////////////////////////////////

	pthread_create(&confirm, NULL, getConfirmation, p_enter);	//En attente d'un touche et la stocke dans le pointeur enter

/////////////////////////////// FIN ATTENTION ////////////////////////////

	while(enter == 0){	//en attente d'un clique du clavier ou autre pour sortir du loadingMode
		continueGame();	//Clignoter la demande d'action du clavier
		refresh();
	}
	attroff(COLOR_PAIR(4));
}

void loadingMenu(){
	loadingBar();
	refresh();
}


///////////////////////////////////////////////////////////////////////////

///////////////////////				MOUSE CLICK			/////////////////////////////

///////////////////////////////////////////////////////////////////////////
/**Initialisation de ncurses**/
void ncurses_initialiser() {
  initscr();	          /* Démarre le mode ncurses */
  cbreak();	            /* Pour les saisies clavier (desac. mise en buffer) */
  keypad(stdscr, TRUE);	/* Active les touches spécifiques */
  refresh();            /* Met a jour l'affichage */
  curs_set(FALSE);      /* Masque le curseur */
}


/**Initialisation des couleurs**/
void ncurses_couleurs() {
  /* Vérification du support de la couleur */
  if(has_colors() == FALSE) {
    endwin();
    fprintf(stderr, "Le terminal ne supporte pas les couleurs.\n");
    exit(EXIT_FAILURE);
  }

  /* Activation des couleurs */
	start_color();
	int COLOR_BACKGROUND = 10;
	int COLOR_WHITE_CASE = 11;
	int COLOR_BLACK_CASE = 12;
	int COLOR_GREEN_CASE = 14;
	int COLOR_RED_CASE = 15;
	int COLOR_BLUE_CASE = 16;
	int COLOR_BLACK_PERSO = 17;
	int COLOR_RANDOM = 18;
	int COLOR_PICTURE = 19;
	int COLOR_VALIDATE = 20;
	int COLOR_UNVALIDATE = 21;
	int COLOR_RED_PERSO = 22;
	int COLOR_YELLOW_HELP = 23;

	//init_color(COLOR_BACKGROUND, 0, 76, 153);
	init_color(COLOR_BACKGROUND, 0, 0, 80);
	init_color(COLOR_BLACK_CASE, 250, 250, 250);
	init_color(COLOR_WHITE_CASE, 1000, 1000, 1000);
	init_color(COLOR_GREEN_CASE, 0, 500, 0);
	init_color(COLOR_RED_CASE, 600, 0, 0);
	init_color(COLOR_BLUE_CASE, 0, 0, 1000);
	init_color(COLOR_BLACK_PERSO, 0, 0, 0);
	init_color(COLOR_RANDOM, 224, 568, 568);
	init_color(COLOR_PICTURE, 224, 568, 568);
	init_color(COLOR_VALIDATE, 0, 1000, 0);
	init_color(COLOR_UNVALIDATE, 550, 0, 0);
	init_color(COLOR_RED_PERSO, 1000, 0, 0);
	init_color(COLOR_YELLOW_HELP, 1000, 1000, 0);

//////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////// ATTENTION DES COULEURS NE SONT PAS UTILISÉ DANS LE CODE //////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

	init_pair(1,  COLOR_BACKGROUND, COLOR_BACKGROUND);   //color of background
	init_pair(2,  COLOR_WHITE_CASE, COLOR_WHITE_CASE);   //color of black case
	init_pair(3,  COLOR_BLACK_CASE, COLOR_BLACK_CASE);   //color of cross case
	init_pair(4,  COLOR_WHITE_CASE, COLOR_BACKGROUND);   //color of draw
	init_pair(5,  COLOR_GREEN_CASE, COLOR_BACKGROUND);   //color when there is validation   //expired---> delete
	init_pair(6,  COLOR_GREEN_CASE, COLOR_GREEN_CASE);   //color of yesBox
	init_pair(7,  COLOR_WHITE_CASE, COLOR_GREEN_CASE);   //color of text in yesBox
	init_pair(8,  COLOR_RED_CASE, COLOR_RED_CASE);       //color of noBox
	init_pair(9,  COLOR_WHITE_CASE, COLOR_RED_CASE);     //color of text in noBox
	init_pair(10, COLOR_BLACK_PERSO, COLOR_BLACK_PERSO); //color of text in homeBox
	init_pair(11, COLOR_WHITE_CASE, COLOR_BLACK_PERSO);  //color of text in homeBox
	init_pair(12, COLOR_RANDOM, COLOR_RANDOM);           //color of random background
	init_pair(14, COLOR_WHITE_CASE, COLOR_RANDOM);       //color of random text
	init_pair(15, COLOR_PICTURE, COLOR_PICTURE);         //color picture background
	init_pair(16, COLOR_WHITE_CASE, COLOR_PICTURE);     //color picture text
	init_pair(17, COLOR_VALIDATE, COLOR_BACKGROUND);     //color validate_case
	init_pair(18, COLOR_UNVALIDATE, COLOR_UNVALIDATE);   //color unvalidate-case
	init_pair(19, COLOR_WHITE_CASE, COLOR_UNVALIDATE);   //color text of unvalidate_case
	init_pair(20, COLOR_RED_CASE, COLOR_BACKGROUND);     //color box exit
	init_pair(21, COLOR_RED_PERSO, COLOR_BACKGROUND);    //color gameOver
	init_pair(23, COLOR_PICTURE, COLOR_BACKGROUND);       //color point setBackground
	init_pair(24, COLOR_YELLOW_HELP, COLOR_YELLOW_HELP);	//color help button
	init_pair(25, COLOR_BLACK_PERSO, COLOR_YELLOW_HELP);	//Color text Help Button

	bkgd(COLOR_PAIR(1));	//Mise en place de la couleur d'arrière plan
}

/**Initialisation de la souris**/
void ncurses_souris() {
  if(!mousemask(ALL_MOUSE_EVENTS, NULL)) {
    endwin();
    fprintf(stderr, "Erreur lors de l'initialisation de la souris.\n");
    exit(EXIT_FAILURE);
  }

  if(has_mouse() != TRUE) {
    endwin();
    fprintf(stderr, "Aucune souris n'est détectée.\n");
    exit(EXIT_FAILURE);
  }
}

/**Pour récupérer les coordonnées (x,y) du clic de la souris**/
int click_souris() {
  MEVENT event ;
  int ch;

  while((ch = getch()) != KEY_F(1)){
    switch(ch){
      case KEY_F(2): /*Pour quitter la boucle*/
	 	return 1;
 	 case KEY_MOUSE:
        	if(getmouse(&event) == OK){
      	   	C = event.x;
      	   	L = event.y;
        	 	if(event.bstate & BUTTON1_CLICKED) {
        	   		return 0;
        	 	}
 		}
    	}
  }
  return 0;
}

/*Pour récupérer les données saisies par l'utilisateur sans bloquer le jeu*/
char key_pressed() {
	struct termios oldterm, newterm;
	int oldfd;
	char c, result = 0;
	tcgetattr (STDIN_FILENO, &oldterm);
	newterm = oldterm;
	newterm.c_lflag &= ~(ICANON | ECHO);
	tcsetattr (STDIN_FILENO, TCSANOW, &newterm);
	oldfd = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl (STDIN_FILENO, F_SETFL, oldfd | O_NONBLOCK);
	c = getchar();
	tcsetattr (STDIN_FILENO, TCSANOW, &oldterm);
	fcntl (STDIN_FILENO, F_SETFL, oldfd);
	if (c != EOF) {
		ungetc(c, stdin);
		result = getchar();
	}
	return result;
}

void LANCEMENT_JEU(){
  while (click_souris() == 0){
    clear();
    printw("Vous avez cliqué sur la position (%d, %d)\n", L, C);
    refresh();
  }
}

///////////////////////////////////////////////////////////////////////////

///////////////////////			SET SOUND GAME		/////////////////////////////

///////////////////////////////////////////////////////////////////////////
void *put_soundtrackOpening(void *arg){
	system("play -q 'sound/soundWelcomeTo_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}

void *put_soundCase(void *arg){
	system("play -q 'sound/soundCase_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}

void *put_soundYes(void *arg){
	system("play -q 'sound/soundYes_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}

void *put_soundNo(void *arg){
	system("play -q 'sound/soundNo_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}

void *put_soundNavigateMenu(void *arg){
	system("play -q 'sound/soundNavigate_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}

void *put_soundValidateGame(void *arg){
	system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
  	(void) arg;
  	pthread_exit(NULL);
}
