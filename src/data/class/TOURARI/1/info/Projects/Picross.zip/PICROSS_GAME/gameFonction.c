#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>

#include "resource.h"
#include "gameFonction.h"

/*
TOURARI Jérémy
*/

//////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////				START MENU			/////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////
void putTitlePICROSS(){
	WINDOW *titleBox;
	FILE *title;

	titleBox = subwin(stdscr, 9, 68, 2, COLS/2 - 70/2);
	wattron(titleBox, COLOR_PAIR(20));
	wborder(titleBox, ' ', ' ', ' ', ACS_HLINE, ' ', ' ', ' ', ' ');
	wattroff(titleBox, COLOR_PAIR(20));

	char charTitle;

	title = fopen("text/title.txt", "r");	//Ouvre le fichier avec le titre PICROSS GAME

	while((charTitle = fgetc(title)) != EOF) {	//Écrit le titre
		wattron(titleBox, COLOR_PAIR(4));
		wprintw(titleBox, "%c",charTitle);
		wattroff(titleBox, COLOR_PAIR(4));
	}

	wrefresh(titleBox);	//Rafraichi pour afficher le résultat
	fclose(title);
	delwin(titleBox);
}

void showModeRandom(WINDOW *random, int height, int width, int start_Y, int start_X){	//Dessine le carré du random game (celui de gauche)
	wclear(random);
	random = subwin(stdscr, height, width, start_Y, start_X);
	wbkgd(random, COLOR_PAIR(12));
	wattron(random, COLOR_PAIR(14));
	mvwprintw(random, height/2, width/2 - 5, "RANDOM GAME");
	wattroff(random, COLOR_PAIR(14));
	wrefresh(random);
	refresh();
}

void showLevelRandom(WINDOW *random, int height, int width, int start_Y, int start_X){	//Affiche les niveaux du randomGame
	wclear(random);
	random = subwin(stdscr, height, width, start_Y, start_X);
	wbkgd(random, COLOR_PAIR(12));
	wattron(random, COLOR_PAIR(14));
	wattron(random, A_UNDERLINE);
	mvwprintw(random, height/2 - 4,width/2 - 6, "RANDOM GAME");
	wattroff(random, A_UNDERLINE);
	mvwprintw(random, height/2 - 1, width/2 - 8, "Easy     **");
	mvwprintw(random, height/2, width/2 - 8, "Normal   ****");
	mvwprintw(random, height/2 + 1, width/2 - 8, "Hard     ******");
	attron(A_BOLD);
	mvwprintw(random, height/2 + 4, width/2 - 7, "XXX Custom XXX");
	attroff(A_BOLD);
	wattroff(random, COLOR_PAIR(14));
	wrefresh(random);
	refresh();
}

void showModePicture(WINDOW *picture, int height, int width, int start_Y, int start_X){	//Dessine le carré du picture game (celui de droite)
	wclear(picture);
	picture = subwin(stdscr, height, width, start_Y, start_X);
	wbkgd(picture, COLOR_PAIR(12));
	wattron(picture, COLOR_PAIR(14));
	mvwprintw(picture, height/2, width/2 - 5, "PICTURE GAME");
	wattroff(picture, COLOR_PAIR(14));
	wrefresh(picture);
	refresh();
}

void showLevelPicture(WINDOW *picture, int height, int width, int start_Y, int start_X){	//Affiche les niveaux du pictureGame
	wclear(picture);
	picture = subwin(stdscr, height, width, start_Y, start_X);
	wbkgd(picture, COLOR_PAIR(12));
	wattron(picture, COLOR_PAIR(16));
	wattron(picture, A_UNDERLINE);
	mvwprintw(picture, height/2 - 5, width/2 - 6, "PICTURE GAME");
	wattroff(picture, A_UNDERLINE);
	mvwprintw(picture, height/2 - 2, width/2 - 7, "Level 1  *");
	mvwprintw(picture, height/2 - 1, width/2 - 7, "Level 2  **");
	mvwprintw(picture, height/2, width/2 - 7, "Level 3  ***");
	mvwprintw(picture, height/2 + 1, width/2 - 7, "Level 4  ****");
	mvwprintw(picture, height/2 + 2, width/2 - 7, "Level 5  *****");
	mvwprintw(picture, height/2 + 4, width/2 - 6, "XXX GUEST XXX");
	wattroff(picture, COLOR_PAIR(16));
	wrefresh(picture);
	refresh();
}

void showAuthorBox(){
	int i, j;
	int width = COLS/3 - 6;
	int height = LINES/2;
	int start_x = 4;
	int start_y = 15;

	attron(COLOR_PAIR(4));
	mvprintw(start_y + 1, start_x + width/2 - 10, "AUTHOR'S INFORMATIONS");
	mvprintw(start_y + 3, start_x + 2, "TEACHERS : ");
	mvprintw(start_y + 5, start_x + 5, "RAQUEL MARTINS Eunice");
	mvprintw(start_y + 7, start_x + 5, "FRANCOIS Michael");

	mvprintw(start_y + 11, start_x + 2, "STUDENTS : ");
	mvprintw(start_y + 13, start_x + 5, "TOURARI Jérémy");
	mvprintw(start_y + 15, start_x + 5, "BARREIRA Nina");
	mvprintw(start_y + height - 1, start_x + width/2 - 7, "SCHOOL : ESIEA");

	for (i = 0; i < width; i++){
		mvaddch(start_y, start_x + i, ACS_HLINE);
		mvaddch(start_y + height, start_x + i, ACS_HLINE);
		mvaddch(start_y + 2, start_x + i, ACS_HLINE);
		mvaddch(start_y + height - 2, start_x + i, ACS_HLINE);
	}
	for (j = 0; j < height; j++){
		mvaddch(start_y + j, start_x, ACS_VLINE);
		mvaddch(start_y + j, start_x + width, ACS_VLINE);
	}
	mvaddch(start_y + 2, start_x, ACS_LTEE);
	mvaddch(start_y + 2, start_x + width, ACS_RTEE);
	mvaddch(start_y + height - 2, start_x, ACS_LTEE);
	mvaddch(start_y + height - 2, start_x + width, ACS_RTEE);
	mvaddch(start_y, start_x, ACS_ULCORNER);
	mvaddch(start_y, start_x + width, ACS_URCORNER);
	mvaddch(start_y + height, start_x, ACS_LLCORNER);
	mvaddch(start_y + height, start_x + width, ACS_LRCORNER);

	attroff(COLOR_PAIR(4));
}

void showRules(){
	int i, j;
	int width = COLS/3 - 6;
	int height = LINES/2;
	int start_x = COLS/2 - width/2;
	int start_y = 15;

	attron(COLOR_PAIR(4));
	mvprintw(start_y + 4, start_x + 3, "Fill a board thanks to the indications.");
	mvprintw(start_y + 6, start_x + 3, "0 : black case\t1 : white case");
	mvprintw(start_y + 8, start_x + 2, "Example :");
	mvprintw(start_y + 9, start_x + 3, "0 0 0 0 0 -> 0");
	mvprintw(start_y + 10, start_x + 3, "1 1 1 1 1 -> 5");
	mvprintw(start_y + 11, start_x + 3, "1 1 0 1 1 -> 2 2");
	mvprintw(start_y + 12, start_x + 3, "1 0 1 1 1 -> 1 3");
	mvprintw(start_y + 13, start_x + 3, "1 1 1 0 1 -> 3 1");
	mvprintw(start_y + 14, start_x + 3, "1 0 1 0 1 -> 1 1 1");

	mvprintw(start_y + height - 1, start_x + width/2 - 1, "...");

	for (i = 0; i < width; i++){
		mvaddch(start_y, start_x + i, ACS_HLINE);
		mvaddch(start_y + height, start_x + i, ACS_HLINE);
		mvaddch(start_y + 2, start_x + i, ACS_HLINE);
		mvaddch(start_y + height - 2, start_x + i, ACS_HLINE);
	}
	for (j = 0; j < height; j++){
		mvaddch(start_y + j, start_x, ACS_VLINE);
		mvaddch(start_y + j, start_x + width, ACS_VLINE);
	}
	mvaddch(start_y + 2, start_x, ACS_LTEE);
	mvaddch(start_y + 2, start_x + width, ACS_RTEE);
	mvaddch(start_y + height - 2, start_x, ACS_LTEE);
	mvaddch(start_y + height - 2, start_x + width, ACS_RTEE);
	mvaddch(start_y, start_x, ACS_ULCORNER);
	mvaddch(start_y, start_x + width, ACS_URCORNER);
	mvaddch(start_y + height, start_x, ACS_LLCORNER);
	mvaddch(start_y + height, start_x + width, ACS_LRCORNER);
	mvprintw(start_y + 1, start_x + width/2 - 3, "RULES");
	attroff(COLOR_PAIR(4));
}

void showMessageProgrammer(){
	int i, j;
	int width = COLS/3 - 6;
	int height = LINES/2;
	int start_x = COLS - width - 4;
	int start_y = 15;

	attron(COLOR_PAIR(4));
	mvprintw(start_y + 3, start_x + 2 , "ADVICES : YOU NEED TO INSTALL...");
	mvprintw(start_y + 5, start_x + 5 , "  sudo apt-get install sox");
	mvprintw(start_y + 6, start_x + 5 , "  sudo apt-get install libsox-fmt-all");
	mvprintw(start_y + 7, start_x + 5 , "  sudo apt-get install libpthread*");
	mvprintw(start_y + 8, start_x + 5 , "  sudo apt-get install libncurses*");
	mvprintw(start_y + 9, start_x + 5 , "  sudo apt-get install make");
	mvprintw(start_y + 10, start_x + 5, "  sudo apt-get install gcc");
	mvprintw(start_y + 12, start_x + 2, "THE AUDIO HEADSET IS RECOMMANDED");

	mvprintw(start_y + height - 5, start_x + width/2 - 15, "We hope you'll enjoy our game,");
	mvprintw(start_y + height - 4, start_x + width/2 - 5, "Good Luck !");
	mvprintw(start_y + height - 1, start_x + width/2 - 6, "Jérémy & Nina");

	for (i = 0; i < width; i++){
		mvaddch(start_y, start_x + i, ACS_HLINE);
		mvaddch(start_y + height, start_x + i, ACS_HLINE);
		mvaddch(start_y + 2, start_x + i, ACS_HLINE);
		mvaddch(start_y + height - 2, start_x + i, ACS_HLINE);
	}
	for (j = 0; j < height; j++){
		mvaddch(start_y + j, start_x, ACS_VLINE);
		mvaddch(start_y + j, start_x + width, ACS_VLINE);
	}
	mvaddch(start_y + 2, start_x, ACS_LTEE);
	mvaddch(start_y + 2, start_x + width, ACS_RTEE);
	mvaddch(start_y + height - 2, start_x, ACS_LTEE);
	mvaddch(start_y + height - 2, start_x + width, ACS_RTEE);
	mvaddch(start_y, start_x, ACS_ULCORNER);
	mvaddch(start_y, start_x + width, ACS_URCORNER);
	mvaddch(start_y + height, start_x, ACS_LLCORNER);
	mvaddch(start_y + height, start_x + width, ACS_LRCORNER);
	mvprintw(start_y + 1, start_x + width/2 - 8, "AUTHOR'S MESSAGE");
	attroff(COLOR_PAIR(4));
}

void showHelpMenu(){
	int i;
	int form = 0;
	pthread_t no;

	if (LINES >= 12 && COLS >= 140) form = 1;
	else form = 2;

	if (form == 1){
		clear();
		attron(COLOR_PAIR(4));
		printTitle(fopen("text/informations.txt", "r"), 2, COLS, 1);
		attroff(COLOR_PAIR(4));
		attron(COLOR_PAIR(20));
		for (i = 0; i <= COLS; i++){
			mvaddch(9, i, ACS_HLINE);
		}
		attroff(COLOR_PAIR(20));
		showAuthorBox();
		showRules();
		showMessageProgrammer();
		refresh();
		getch();
		pthread_create(&no, NULL, put_soundNo, NULL);
	}
	if (form == 2){
		clear();
		attron(COLOR_PAIR(4));
		mvprintw(LINES/2, COLS/2 - 16, "Please resize your terminal size");
		mvprintw(LINES/2 + 1, COLS/2 - 16, "Then click anywhere on the screen");
		attroff(COLOR_PAIR(4));
		getch();
	}
}

int startMenu(){		//StartMenu final qui récupère quelle jeu lancé
	int height = 50*LINES/100;
	int width = 2*height;
	int soundTest = 1;
	int oldLine = LINES;
	int oldCol = COLS;
	int form;

	int start_Y = (LINES * 35) / 100;
	int start_X_random = (COLS * 8) / 100;
	int start_X_picture = (COLS * 65) / 100;

	pthread_t navigateMenu;
	pthread_t yes;

	WINDOW *random, *picture, *sound;
	random = subwin(stdscr, height, width, start_Y, start_X_random);
	picture = subwin(stdscr, height, width, start_Y, start_X_picture);
	sound = subwin(stdscr, 3, 10, 5, 0);

	if (LINES >= 32 && COLS >= 90){
		form = 1;
		setBackground();
		putTitlePICROSS();				//Place le titre
		showModeRandom(random, height, width, start_Y, start_X_random);	//Montre le carré randomGame
		showModePicture(picture, height, width, start_Y, start_X_picture);	//Montre le carré pictureGame
		exitGame();
		muteAll(sound);
		showHelp();
	}
	else{
		form = 2;
		clear();
		attron(COLOR_PAIR(4));
		mvprintw(LINES/2, COLS/2 - 11, "Please, increase your terminal size");
		attroff(COLOR_PAIR(4));
	}

	while (click_souris() == 0){
		if (form == 1){
			if ((L > start_Y && L < start_Y + height) && (C > start_X_random && C < start_X_random + width)){	//Affiche les niveaux du randomGame
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				showLevelRandom(random, height, width, start_Y, start_X_random);	//Affiche les niveaux du randomGame
				showModePicture(picture, height, width, start_Y, start_X_picture);
				refresh();
				click_souris();	//Redemande un click pour choisir le niveau
				if (L == start_Y + height/2 - 1 && (C > start_X_random && C < start_X_random + width)){	//Niveau facile
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 1;
				}
				if (L == start_Y + height/2 && (C > start_X_random && C < start_X_random + width)){	//Niveau normal
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 2;
				}
				if (L == start_Y + height/2 + 1 && (C > start_X_random && C < start_X_random + width)){	//Niveau difficile
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 3;
				}
				if (L == start_Y + height/2 + 4 && (C > start_X_random && C < start_X_random + width)){	//Niveau personnalisé
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 4;
				}
				if ((L >= 0 && L <= 5) && (C >= 0 && C <= 10)){		//Bouton Exit_Gam
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					clear();
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 0;
				}
			}
			if ((L > start_Y && L < start_Y + height) && (C > start_X_picture && C < start_X_picture + width)){		//Affiche les niveaux du picture game
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				showModeRandom(random, height, width, start_Y, start_X_random);
				showLevelPicture(picture, height, width, start_Y, start_X_picture);//Montre les niveaux du pictureGame
				refresh();
				click_souris();	//redemande un click pour choisir le niveau
				if (L == start_Y + height/2 - 2 && (C > start_X_picture && C < start_X_picture + width)){	//Level 1
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 5;
				}
				if (L == start_Y + height/2 - 1 && (C > start_X_picture && C < start_X_picture + width)){	//Level 2
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 6;
				}
				if (L == start_Y + height/2 && (C > start_X_picture && C < start_X_picture + width)){	//Level 3
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 7;
				}
				if (L == start_Y + height/2 + 1 && (C > start_X_picture && C < start_X_picture + width)){	//Level 4
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 8;
				}
				if (L == start_Y + height/2 + 2 && (C > start_X_picture && C < start_X_picture + width)){	//Level 5
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 9;
				}
				if (L == start_Y + height/2 + 4 && (C > start_X_picture && C < start_X_picture + width)){	//Level 5
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					if (LINES - 5 > ((LINES*40) / 100) + 17) loadingMenu();
					system("play -q 'sound/soundValidate_ON.mp3' repeat 0 >/dev/null 2>&1");
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 10;
				}
				if ((L >= 0 && L <= 5) && (C >= 0 && C <= 10)){		//Bouton ExitGame
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					clear();
					delwin(random);
					delwin(picture);
					delwin(sound);
					return 0;
				}
			}
		}
		if ((L >= 0 && L < 5) && (C >= 0 && C <= 10)){	//Bouton ExitGame
			pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
			clear();
			delwin(random);
			delwin(picture);
			delwin(sound);
			return 0;
		}
		if ((L > 5 && L <= 8) && (C >= 0 && C <= 10)){	//Bouton SOUND GLB
			 soundTest++;
			 soundTest = soundTest%2;
			 pthread_create(&yes, NULL, put_soundYes, NULL);
			 if (soundTest == 1) soundON();
			 if (soundTest == 0) soundOFF();
			 muteAll(sound);
	  	}
		if ((L >= 0 && L <= 7) && (C >= COLS - 14 && C <= COLS)){	//Bouton ExitGame
			pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
			showHelpMenu();
			clear();
			setBackground();
			putTitlePICROSS();				//Place le titre
			showModeRandom(random, height, width, start_Y, start_X_random);	//Montre le carré randomGame
			showModePicture(picture, height, width, start_Y, start_X_picture);	//Montre le carré pictureGame
			exitGame();
			muteAll(sound);
			showHelp();
		}

	  	if (oldLine != LINES || oldCol != COLS){
		//////////////////////////////////////////////////////////////////////
		// ACTUALISATION DES VALEURS EN FONCTION DE LA TAILLE DE LA CONSOLE //
		//////////////////////////////////////////////////////////////////////
	  		height = 50*LINES/100;
			width = 2*height;
	  		start_Y = (LINES * 35) / 100;
			start_X_random = (COLS * 8) / 100;
			start_X_picture = (COLS * 65) / 100;
			oldLine = LINES;
			oldCol = COLS;

			if (LINES >= 32 && COLS >= 90){		//Vérification de la place pour afficher tout les éléments du startMenu()
				form = 1;
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				clear();
				setBackground();
				putTitlePICROSS();				//Place le titre
				showModeRandom(random, height, width, start_Y, start_X_random);	//Montre le carré randomGame
				showModePicture(picture, height, width, start_Y, start_X_picture);	//Montre le carré pictureGame
				exitGame();
				muteAll(sound);
				showHelp();
			}
			else {		//Si la taille de la console est insuffisante, alors nous d'augmenter la taille de la console
				form = 2;
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				clear();
				attron(COLOR_PAIR(4));
				mvprintw(LINES/2, COLS/2 - 11, "Please, increase your terminal size");
				attroff(COLOR_PAIR(4));
			}
		}
	}
	delwin(random);
	delwin(picture);
	delwin(sound);
	return 0;
}


///////////////////////////////////////////////////////////////////////////

///////////////////////	RANDOM / PICTURE GAME	/////////////////////////////

///////////////////////////////////////////////////////////////////////////
int pictureGame(int level){
	FILE *level1, *level2, *level3, *level4, *level5, *guest;	//déclaration des fichier avec les niveaux du pictureGame
	level1 = fopen("pictureLevel/level1.txt", "r");		//chargement du niveau 1
	level2 = fopen("pictureLevel/level2.txt", "r");		//chargement du niveau 2
	level3 = fopen("pictureLevel/level3.txt", "r");		//chargement du niveau 3
	level4 = fopen("pictureLevel/level4.txt", "r");		//chargement du niveau 4
	level5 = fopen("pictureLevel/level5.txt", "r");		//chargement du niveau 5
	guest  = fopen("pictureLevel/guest.txt", "r");

	int nbLin, nbCol;		//Déclaration du nombre de ligne et de colonne
	int coord_X = 0;		//Déclaration de la coordonnées X du clique de la souris
	int coord_Y = 0;		//Déclaration de la coordonnées Y du clique de la souris
	int size[4];			//Déclaration de la taille du tableau
	int restart = 0;

	if (level == 1) fscanf(level1, "%d %d", &nbLin, &nbCol);
	if (level == 2) fscanf(level2, "%d %d", &nbLin, &nbCol);
	if (level == 3) fscanf(level3, "%d %d", &nbLin, &nbCol);
	if (level == 4) fscanf(level4, "%d %d", &nbLin, &nbCol);
	if (level == 5) fscanf(level5, "%d %d", &nbLin, &nbCol);
	if (level == 6) fscanf(guest,  "%d %d", &nbLin, &nbCol);

	int TAB_player[nbLin][nbCol];	//Tableau réponse pour le niveau 1
	int TAB_complete[nbLin][nbCol];	//Tableau joueur pour le niveau 1
	int seqLin[nbCol];
	int seqCol[nbLin];

	if (level == 1) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, level1);
	if (level == 2) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, level2);
	if (level == 3) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, level3);
	if (level == 4) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, level4);
	if (level == 5) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, level5);
	if (level == 6) initiatePictureGame(nbLin, nbCol, TAB_player, TAB_complete, guest);

	getSeqLinCol(nbLin, nbCol, TAB_complete, seqLin, seqCol);
	getSize(nbLin, nbCol, seqLin, seqCol, size);
	int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3]; //Position de départ du tableau en Y pour le niveau 1
	int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];	//Position de départ du tableau en X pour le niveau 1
	showBOARD(nbLin, nbCol, TAB_player, TAB_complete, start_Y, start_X, size);	//Montre le tableau initiale pour le niveau 1
	exitGame();	//Bouton ExitGame
	mute();
	refresh();
	runGame(start_Y, start_X, nbLin, nbCol, TAB_player, TAB_complete, coord_Y, coord_X, size);	//Joue le jeu pour le niveau 1
	restart = setGameOver(nbLin, nbCol, TAB_player, TAB_complete);	//test la variable pour recommencer le niveau

	fclose(level1);
	fclose(level2);
	fclose(level3);
	fclose(level4);
	fclose(level5);
	fclose(guest);

	return restart;	//retourne la variable pour tester le restart
}

int randomGame(int nbLin, int nbCol){
  int TAB_player[nbLin][nbCol];				//Tableau réponse
  int TAB_complete[nbLin][nbCol];	//Tableau joueur
  int coord_X = 0;							//Coordonner de la souris en X
  int coord_Y = 0;							//Coordonner de la souris en Y
  int size[4]; 									//{widthLeftColFix, heightLeftColFix, widthTopColFix, heightTopColFix}
  int restart = 0;

  int seqLin[nbCol];
  int seqCol[nbLin];									//Variable de test pour recommencer le jeu

  srand(time(NULL));		//Obtenir un aléatoire réel

  initiateRandomGame(nbLin, nbCol, TAB_player, TAB_complete);	//Initialisation des tableaux à 0, et du tableau réponse
  getSeqLinCol(nbLin, nbCol, TAB_complete, seqLin, seqCol);
  getSize(nbLin, nbCol, seqLin, seqCol, size);	//Calcul la taille du Tableaus en fonction du nombre de lignes/ Colonne et de la taille de la fenêtre

  int start_Y = LINES/2 - (nbLin*size[1] + size[3])/2 + size[3];	//Position de départ du tableau en Y
  int start_X = COLS/2 - (nbCol*size[2] + size[0])/2 + size[0];		//Position de départ du tableau en X

  showBOARD(nbLin, nbCol, TAB_player, TAB_complete, start_Y, start_X, size);	//Montre le tableau initiale
  exitGame();		//Bouton ExitGame
  mute();
  refresh();
  runGame(start_Y, start_X, nbLin, nbCol, TAB_player, TAB_complete, coord_Y, coord_X, size);	//Joue le jeu
  restart = setGameOver(nbLin, nbCol, TAB_player, TAB_complete);				//Montre le game over et retourne la valeur de restart

  return restart;
}


///////////////////////////////////////////////////////////////////////////

//////////////////////////  CUSTOM RANDOM   //////////////////////////////

//////////////////////////////////////////////////////////////////////////
void infoMax(){
	int i, j;
	int width = 50;
	int height = 6;
	int start_Y = LINES/2 - height/2;
	int start_X = COLS/2 - width/2;
	int maxLin = (LINES - LINES/4 - 2)/2;
	int maxCol = (COLS - COLS/4 - 4)/3 - 1;

	attron(COLOR_PAIR(4));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
			if (i == 0 && j == width/2) mvaddch(start_Y + i, start_X + j, ACS_BTEE);
			if (i == height-1 && j == width/2) mvaddch(start_Y + i, start_X + j, ACS_TTEE);
		}
	}

	attron(A_UNDERLINE);
	mvprintw(start_Y + 1, start_X + width/2 - 7, "Informations :");
	attroff(A_UNDERLINE);
	mvprintw(start_Y + height/2, start_X + width/2 - 16, "Nb Max Line : %d   Nb Max Col : %d", maxLin, maxCol);
	attroff(COLOR_PAIR(4));
}

void boxNbLinNbCol(){
	int i, j;
	int width = 16;
	int height = 5;
	int start_X_LIN = COLS/4 - width/2;
	int start_X_COL = 3*COLS/4 - width/2;
	int start_Y = 3*LINES/4 - height/2;

	attron(COLOR_PAIR(8));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			mvaddch(start_Y + i, start_X_LIN + j, ACS_CKBOARD);
			mvaddch(start_Y + i, start_X_COL + j, ACS_CKBOARD);
		}
	}
	attroff(COLOR_PAIR(8));

	attron(COLOR_PAIR(9));
	mvprintw(start_Y + height/2, COLS/4 - 3, "NbLin ?");
	mvprintw(start_Y + height/2, 3*COLS/4 - 3, "NbCol ?");
	attroff(COLOR_PAIR(9));
}

int askBoxNbLin(){
	int i, j;
	int nbLin;
	int width = 16;
	int height = 5;
	int start_X = COLS/4 - width/2;
	int start_Y = 3*LINES/4 - height/2;

	attron(COLOR_PAIR(20));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			mvaddch(start_Y + i, start_X + j, ' ');
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
		}
	}
	mvprintw(start_Y + height/2, start_X + width/2 - 3, "       ");
	mvscanw(start_Y + height/2, start_X + width/2 - 1, "%d", &nbLin);
	attroff(COLOR_PAIR(20));
	return nbLin;
}

int askBoxNbCol(){
	int i, j;
	int nbCol;
	int width = 16;
	int height = 5;
	int start_X = 3*COLS/4 - width/2;
	int start_Y = 3*LINES/4 - height/2;

	attron(COLOR_PAIR(20));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			mvaddch(start_Y + i, start_X + j, ' ');
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
		}
	}
	mvprintw(start_Y + height/2, start_X + width/2 - 3, "       ");
	mvscanw(start_Y + height/2, start_X + width/2 - 1, "%d", &nbCol);
	attroff(COLOR_PAIR(20));

	return nbCol;
}

void boxNbLinValidate(int nbLin){
	int i, j;
	int width = 16;
	int height = 5;
	int start_X = COLS/4 - width/2;
	int start_Y = 3*LINES/4 - height/2;

	attron(COLOR_PAIR(17));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
		}
	}

	mvprintw(start_Y + height/2, start_X + width/2 - 1, "%d", nbLin);
	attroff(COLOR_PAIR(17));
}

void boxNbColValidate(int nbCol){
	int i, j;
	int width = 16;
	int height = 5;
	int start_X = 3*COLS/4 - width/2;
	int start_Y = 3*LINES/4 - height/2;

	attron(COLOR_PAIR(17));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			if (i == 0) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (i == height-1) mvaddch(start_Y + i, start_X + j, ACS_HLINE);
			if (j == 0) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (j == width-1) mvaddch(start_Y + i, start_X + j, ACS_VLINE);
			if (i == 0 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_ULCORNER);
			if (i == 0 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_URCORNER);
			if (i == height-1 && j == 0) mvaddch(start_Y + i, start_X + j, ACS_LLCORNER);
			if (i == height-1 && j == width - 1) mvaddch(start_Y + i, start_X + j, ACS_LRCORNER);
		}
	}
	mvprintw(start_Y + height/2, start_X + width/2 - 1, "%d", nbCol);
	attroff(COLOR_PAIR(17));
}

void middleDrawLine(){
	int i;
	attron(COLOR_PAIR(4));
	for (i = 0; i < LINES/2 - 3; i++){
		mvaddch(i, COLS/2, ACS_VLINE);
	}
	for (i = LINES/2 + 3; i <= LINES; i++){
		mvaddch(i, COLS/2, ACS_VLINE);
	}
	attroff(COLOR_PAIR(4));
}

void getDim(int *p_lin, int *p_col){
	int maxLin, maxCol;
	int oldLine = LINES;
	int oldCol = COLS;
	int form;
	pthread_t navigateMenu;
	pthread_t yes;

	maxLin = (LINES - LINES/4)/2;
	maxCol = (COLS - COLS/4)/3 - 1;

	*p_lin = maxLin + 1;
	*p_col = maxCol + 1;

	if (LINES >= 38 && COLS >= 85){
		form = 1;
		clear();			//demarrer d'une page blanche
		attron(COLOR_PAIR(4));
		printTitle(fopen("text/nbLin.txt", "r"), 1, COLS/2, 1);
		printTitle(fopen("text/nbCol.txt", "r"), 1, 3*COLS/2, 1);
		attroff(COLOR_PAIR(4));
		infoMax();			//Placer les informations du tableau
		boxNbLinNbCol();
		middleDrawLine();	//Dessine la ligne de milieu de séparation
	}
	else {
		form = 2;
		clear();
		attron(COLOR_PAIR(4));
		mvprintw(LINES/2, COLS/2 - 11, "Enter the line number (max %d) : ", maxLin);
		scanw("%d", &*p_lin);
		clear();
		mvprintw(LINES/2, COLS/2 - 12, "Enter the column number (max %d) : ", maxCol);
		scanw("%d", &*p_col);
		attroff(COLOR_PAIR(4));
	}
	while (click_souris() == 0){
		if (form == 1){
			if ((L >= 3*LINES/4 - 3 && L <= 3*LINES/4 + 3) && (C >= COLS/4 - 8 && C <= COLS/4 + 8)){
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				*p_lin = askBoxNbLin();
				if (*p_lin <= maxLin - 1 && *p_lin > 0){
					pthread_create(&yes, NULL, put_soundYes, NULL);
					boxNbLinValidate(*p_lin);
				}
			}
			if ((L >= 3*LINES/4 - 3 && L <= 3*LINES/4 + 3) && (C >= 3*COLS/4 - 8 && C <= 3*COLS/4 + 8)){
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				*p_col = askBoxNbCol();
				if (*p_col <= maxCol - 1 && *p_col > 0){
					pthread_create(&yes, NULL, put_soundYes, NULL);
					boxNbColValidate(*p_col);
				}
			}
		}
		if (form == 2){
			attron(COLOR_PAIR(4));
			mvprintw(1, COLS/2 - 19, "You can NOT return on the other menu !");
			mvprintw(2, COLS/2 - 18, "So enter your table dimmension here");
			mvprintw(LINES/2, COLS/2 - 16, "Enter the line number (max %d) : ", maxLin - 1);
			scanw("%d", &*p_lin);
			clear();
			mvprintw(1, COLS/2 - 19, "You can NOT return on the other menu !");
			mvprintw(2, COLS/2 - 15, "So enter your table dimmension here");
			mvprintw(LINES/2, COLS/2 - 16, "Enter the column number (max %d) : ", maxCol - 1);
			scanw("%d", &*p_col);
			attroff(COLOR_PAIR(4));
		}
		if (oldLine != LINES || oldCol != COLS){
		//////////////////////////////////////////////////////////////////////
		// ACTUALISATION DES VALEURS EN FONCTION DE LA TAILLE DE LA CONSOLE //
		//////////////////////////////////////////////////////////////////////
			maxLin = (LINES - LINES/4)/2;
			maxCol = (COLS - COLS/4)/3 - 1;
			*p_lin = maxLin + 1;
			*p_col = maxCol + 1;
			oldLine = LINES;
			oldCol = COLS;

			if (LINES >= 30 && COLS >= 85){
				form = 1;
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				clear();			//demarrer d'une page blanche
				attron(COLOR_PAIR(4));
				printTitle(fopen("text/nbLin.txt", "r"), 1, COLS/2, 1);
				printTitle(fopen("text/nbCol.txt", "r"), 1, 3*COLS/2, 1);
				attroff(COLOR_PAIR(4));

				infoMax();			//Placer les informations du tableau
				boxNbLinNbCol();
				middleDrawLine();	//Dessine la ligne de milieu de séparation
			}
			else {
				form = 2;
				pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
				clear();
				attron(COLOR_PAIR(4));
				mvprintw(LINES/2, COLS/2 - 7, "Click anywhere");
				attroff(COLOR_PAIR(4));
			}
		}
		refresh();
		if ((*p_lin <= maxLin && *p_lin > 0) && (*p_col <= maxCol - 1 && *p_col > 0)) break;
	}
	sleep(1);
}

////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////				GAME OVER				///////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////
void showYesButton(){
	int i, j;
	int start_Y = LINES-5;
	int start_X = 0;
	int width = 10;
	int height = 5;

	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			attron(COLOR_PAIR(6));
			mvaddch(start_Y + i, start_X + j, ACS_CKBOARD);
			attroff(COLOR_PAIR(6));
		}
	}
	attron(COLOR_PAIR(7));
	mvprintw(start_Y + height/2, start_X + width/2 - 2, "YES");
	attroff(COLOR_PAIR(7));
}

void showNoButton(){
	int i, j;
	int start_Y = LINES-5;
	int start_X = COLS-10;
	int width = 10;
	int height = 5;

	attron(COLOR_PAIR(8));
	for (i = 0; i < height; i++){
		for (j = 0; j < width; j++){
			mvaddch(start_Y + i, start_X + j, ACS_CKBOARD);
		}
	}
	attroff(COLOR_PAIR(8));
	attron(COLOR_PAIR(9));
	mvprintw(start_Y + height/2, start_X + width/2 - 1, "NO");
	attroff(COLOR_PAIR(9));
}

void setSeparationRestart(){
	int i;
	int start_Y = LINES - 12;

	attron(COLOR_PAIR(4));
	for (i = 0; i < COLS; i++){
		mvaddch(start_Y - 2, i, ACS_HLINE);
	}
	attroff(COLOR_PAIR(4));
}

int setGameOver(int nbLin, int nbCol, int TAB_player[nbLin][nbCol], int TAB_complete[nbLin][nbCol]){
	int oldSizeLin = LINES;
	int oldSizeCol = COLS;
	char answer;
	pthread_t yes;
	pthread_t no;
	pthread_t navigateMenu;

	system("mv sound/soundCase_OFF.mp3 sound/soundCase_ON.mp3 >/dev/null 2>&1");	//restore le bon nom du fichier case.mp3

	clear();
	if (LINES >= 41 && COLS >= 76){
		if (nbLin < 6) {
			showResult(nbLin, nbCol, TAB_complete);
			attron(COLOR_PAIR(21));
			printTitle(fopen("text/gameOver.txt", "r"), 2, COLS, 1);
			attroff(COLOR_PAIR(21));
			setSeparationRestart();
			attron(COLOR_PAIR(4));
			printTitle(fopen("text/restart.txt", "r"), LINES - 12, COLS, 1);
			attroff(COLOR_PAIR(4));
			showYesButton();
			showNoButton();
			while (click_souris() == 0){
				if ((oldSizeLin != LINES) || (oldSizeCol != COLS)){
					clear();
					showResult(nbLin, nbCol, TAB_complete);
					attron(COLOR_PAIR(21));
					printTitle(fopen("text/gameOver.txt", "r"), 2, COLS, 1);
					attroff(COLOR_PAIR(21));
					setSeparationRestart();
					attron(COLOR_PAIR(4));
					printTitle(fopen("text/restart.txt", "r"), LINES - 12, COLS, 1);
					attroff(COLOR_PAIR(4));
					showYesButton();
					showNoButton();
				}
				oldSizeLin = LINES;
				oldSizeCol = COLS;
				if ((L > LINES-5 && L < LINES) && (C > 0 && C < 10)){	//Yes
					pthread_create(&yes, NULL, put_soundYes, NULL);
				    clear();
			    	return 1;
			    }
			    if ((L > LINES-5 && L < LINES) && (C > COLS - 10 && C < COLS)){	//No
					pthread_create(&no, NULL, put_soundNo, NULL);
			    	clear();
			    	return 0;
			    }
			}
		}
		if (nbLin > 5) {
			attron(COLOR_PAIR(21));
			printTitle(fopen("text/gameOver.txt", "r"), 2, COLS, 1);
			attroff(COLOR_PAIR(21));
			setSeparationRestart();
			attron(COLOR_PAIR(4));
			printTitle(fopen("text/menuResult.txt", "r"), LINES/2 - 16/2, COLS, 1);
			printTitle(fopen("text/restart.txt", "r"), LINES - 12, COLS, 1);
			attroff(COLOR_PAIR(4));
			showYesButton();
			showNoButton();
			while (click_souris() == 0){
				if ((oldSizeLin != LINES) || (oldSizeCol != COLS)){
					clear();
					showResult(nbLin, nbCol, TAB_complete);
					attron(COLOR_PAIR(21));
					printTitle(fopen("text/gameOver.txt", "r"), 2, COLS, 1);
					attroff(COLOR_PAIR(21));
					setSeparationRestart();
					attron(COLOR_PAIR(4));
					printTitle(fopen("text/restart.txt", "r"), LINES - 12, COLS, 1);
					attroff(COLOR_PAIR(4));
					showYesButton();
					showNoButton();
				}
				oldSizeLin = LINES;
				oldSizeCol = COLS;
				if ((L > LINES/2 - 16/2 && L < LINES/2 + 16/2) && (C > COLS/2 - 98/2 && C < COLS/2 + 98/2)){
					pthread_create(&navigateMenu, NULL, put_soundNavigateMenu, NULL);
					clear();
					showResult(nbLin, nbCol, TAB_complete);
					showYesButton();
					showNoButton();
				}
				if ((L > LINES-5 && L < LINES) && (C > 0 && C < 10)){
					pthread_create(&yes, NULL, put_soundYes, NULL);
					clear();
			    	return 1;
			    }
			    if ((L > LINES-5 && L < LINES) && (C > COLS - 10 && C < COLS)){
					pthread_create(&no, NULL, put_soundNo, NULL);
					clear();
			    	return 0;
			    }
			}
		}
	}
	else{
		attron(COLOR_PAIR(4));
		mvprintw(LINES/2 - 1, COLS/2 - 12, "Do you want to restart ?");
		mvprintw(LINES/2, COLS/2 - 8, "Press y for yes");
		mvprintw(LINES/2 + 1, COLS/2 - 8, "Press n for no");
		answer = getch();
		clear();
		if (answer == 'y') return 1;
		if (answer == 'n') return 0;
		attroff(COLOR_PAIR(4));
	}
	return 0;
}
