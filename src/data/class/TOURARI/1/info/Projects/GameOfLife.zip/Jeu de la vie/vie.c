#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#define NBLIN 30
#define NBCOL 50
#define NBSTEPS 30

void clearScreen() {
	printf("%c[2J", 0x1B);
	printf("%c[%d;%dH", 0x1B, 1, 1);
}

void showBoard(int nbLin, int nbCol, int iArray[nbLin][nbCol]){
	int i, j;
	clearScreen();
	sleep(1);

	char space = ' ';
	char cell = 'o';
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (iArray[i][j] == 1){
				printf("%c", cell);
			}
			else {
				printf("%c", space);
			}
		}
		printf("\n");
	}
}

void initArray(int nbLin, int nbCol, int iArray[nbLin][nbCol], int value){	//OK
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			iArray[i][j] = value;
		}
	}
}

void showArray (int nbLin, int nbCol, int iArray[nbLin][nbCol]){			//OK
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			printf("%3d", iArray[i][j]);
		}
		printf("\n");
	}
}

void seedRandomCells(int nbLin, int nbCol, int iArray[nbLin][nbCol]){		//OK
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			iArray[i][j] = rand()%5;
		}
	}
}

int getNumberOfNeighboursAlive(int nbLin, int nbCol, int iArray[nbLin][nbCol], int cellLin, int cellCol){	//OK ^_^
	int cpt = 0;
	int i, j;

	for (i = cellLin-1; i <= cellLin+1; i++){
		for (j = cellCol-1; j <= cellCol+1; j++){
			if ( (i != cellLin || j != cellCol) && ( (i >= 0 && i < nbLin) && (j >= 0 && j < nbCol) ) ){
				if (iArray[i][j] == 1){
					cpt++;
				}
			}
		}
	}

	return cpt;

}

int isCellDeadOrAlive(int nbLin, int nbCol, int iArray[nbLin][nbCol], int cellLin, int cellCol){	//OKOK verifier 2 fois et c ok
	if((getNumberOfNeighboursAlive(nbLin,nbCol, iArray, cellLin, cellCol) == 2) && (iArray[cellLin][cellCol] == 1)){
		return 1;
	}
	if(getNumberOfNeighboursAlive(nbLin,nbCol,iArray, cellLin, cellCol) == 3) {
		return 1;
	}
	else {
		return 0;
	}
}

int getNumberOfLivingCells(int nbLin, int nbCol, int iArray[nbLin][nbCol]){			//OK
	int result = 0;
	int i, j;

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			result = result + isCellDeadOrAlive(nbLin, nbCol, iArray, i, j);
		}
	}
	return result;
}

void copyArray(int nbLin, int nbCol, int array1[nbLin][nbCol], int array2[nbLin][nbCol]){	//OK sauvegarde des données
	int i, j;
	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			array2[i][j] = array1[i][j];
		}
	}
}

void runAStep(int nbLin, int nbCol, int iArray[nbLin][nbCol]){	//OK
	int i, j;
	int iArray2[nbLin][nbCol];

	for (i = 0; i < nbLin; i++){
		for (j = 0; j < nbCol; j++){
			if (isCellDeadOrAlive(nbLin,nbCol,iArray,i,j) == 1){
				iArray2[i][j] = 1;
			}
			else {
				iArray2[i][j] = 0;
			}
		}
	}
	copyArray(nbLin, nbCol, iArray2, iArray);
}

int runGame (int nbLin, int nbCol, int iArray[nbLin][nbCol]){
///////////////////// PHASE PREPARATOIRE /////////////////////

	int cellAlive;

	seedRandomCells(nbLin, nbCol, iArray);	//OK

	showBoard(nbLin, nbCol, iArray);		//OK


///////////////////// DEROULEMENT DE LA PARTIE /////////////

	for (int f = 0; f < NBSTEPS; f++){			//OK

		runAStep(nbLin, nbCol, iArray);		//??
		showBoard(nbLin, nbCol, iArray);	//??

		cellAlive = getNumberOfLivingCells(nbLin, nbCol, iArray);	//OK
		printf("\n\nIl y a %d cellules vivantes.\n", cellAlive);	//OK
	}
///////////////////// FIN DE LA PARTIE /////////////////////


	return 0;
}

int main() {
	srand(time(NULL));	//OK

	int board[NBLIN][NBCOL];	//OK

	initArray(NBLIN, NBCOL, board, 0);	//OK

	runGame(NBLIN, NBCOL, board);	//OK

	return 0;
}