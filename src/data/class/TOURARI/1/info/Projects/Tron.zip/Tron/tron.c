#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>

#define NBLIN 30
#define NBCOL 50

void clearScreen() {
     printf("%c[2J", 0x1B);
     printf("%c[%d;%dH", 0x1B, 1, 1);
}

 void showBoard(int nbLin, int nbCol, int **board){
      int i, j;
      clearScreen();
      usleep(100000);
      printf("+");
      for (i = 0; i < 2 * nbCol; i++) printf("-");
      printf("+\n");
      for (i = 0; i < nbLin; i++){
           printf("|");
           for (j = 0; j <= nbCol; j++){
               if (board[i][j] ==  0) printf("  ");
               if (board[i][j] ==  1) printf("\033[31;01mo \033[00m");
               if (board[i][j] ==  2) printf("\033[36;01mo \033[00m");
               if (board[i][j] == -1) printf("\033[33;01mx \033[00m");
           }
           printf("|\n");
      }
      printf("+");
      for (i = 0; i < 2 * nbCol; i++) printf("-");
      printf("+\n");
}

int ** alloc_mat(int nbLin, int nbCol){
     int **mat;
     int i;
     mat = malloc(nbLin * sizeof(int*));
     for (i = 0; i < nbLin; i++){
          mat[i] = malloc(nbCol * sizeof(int));
     }
     return mat;
}

void initArray(int nbLin, int nbCol, int value, int **board){
     int i, j;
     for (i = 0; i < nbLin; i++){
          for (j = 0; j < nbCol; j++){
               board[i][j] = value;
          }
     }
}

void showArray(int nbLin, int nbCol, int **board){
     int i, j;
     for (i = 0; i < nbLin; i++){
          for (j = 0; j < nbCol; j++){
               printf("%3d", board[i][j]);
          }
          printf("\n");
     }
     printf("\n");
}

void initVectPlayer(int nbLin, int nbCol, int **board, int vectPlayer[], int numPlayer){
     if (nbCol < 10){
          printf("Number of columns : %d\n", nbCol);
          printf("You need 10 columns\n");
          exit(-1);
     }
     vectPlayer[0] = nbLin/2;
     if (numPlayer == 1) {
          vectPlayer[1] = 2;
          vectPlayer[2] = 3;
     }
     if (numPlayer == 2) {
          vectPlayer[1] = nbCol - 3;
          vectPlayer[2] = 1;
     }
     board[nbLin/2][2] = 1;
     board[nbLin/2][nbCol - 3] = 2;
}

char key_pressed() {
     struct termios oldterm, newterm;
     int oldfd;
     char c, result = 0;

     tcgetattr (STDIN_FILENO, &oldterm);

     newterm = oldterm;
     newterm.c_lflag &= ~(ICANON | ECHO);

     tcsetattr (STDIN_FILENO, TCSANOW, &newterm);

     oldfd = fcntl(STDIN_FILENO, F_GETFL, 0);

     fcntl (STDIN_FILENO, F_SETFL, oldfd | O_NONBLOCK);

     c = getchar();

     tcsetattr (STDIN_FILENO, TCSANOW, &oldterm);
     fcntl (STDIN_FILENO, F_SETFL, oldfd);

     if (c != EOF) {
          ungetc(c, stdin);
          result = getchar();
     }

     return result;
}

void catchNextEvents(int vectPlayer1[], int vectPlayer2[]){
     int i;
     char keyPressed[10];
     for (i = 0; i < 10; i++){
          keyPressed[i] = key_pressed();
          if (keyPressed[i] == 'q') vectPlayer1[2] = vectPlayer1[2] - 1;
          if (keyPressed[i] == 'd') vectPlayer1[2] = vectPlayer1[2] + 1;
          if (keyPressed[i] == 'k') vectPlayer2[2] = vectPlayer2[2] - 1;
          if (keyPressed[i] == 'm') vectPlayer2[2] = vectPlayer2[2] + 1;

          if (vectPlayer1[2] == 0) vectPlayer1[2] = 4;
          if (vectPlayer1[2] ==  5) vectPlayer1[2] = 1;

          if (vectPlayer2[2] == 0) vectPlayer2[2] = 4;
          if (vectPlayer2[2] ==  5) vectPlayer2[2] = 1;
     }
}

void calculateNextPosition(int vectPlayer[], int nextPosPlayer[]){
     if (vectPlayer[2] == 1){
          nextPosPlayer[0] = vectPlayer[0];
          nextPosPlayer[1] = vectPlayer[1] - 1;
     }
     if (vectPlayer[2] == 2){
          nextPosPlayer[0] = vectPlayer[0] - 1;
          nextPosPlayer[1] = vectPlayer[1];
     }
     if (vectPlayer[2] == 3){
          nextPosPlayer[0] = vectPlayer[0];
          nextPosPlayer[1] = vectPlayer[1] + 1;
     }
     if (vectPlayer[2] == 4){
          nextPosPlayer[0] = vectPlayer[0] + 1;
          nextPosPlayer[1] = vectPlayer[1];
     }
}

void moveVehicule(int **board, int numPlayer, int vectPlayer[], int nextPosPlayer[]){
     int i, j;
     calculateNextPosition(vectPlayer, nextPosPlayer);
     i = nextPosPlayer[0];
     j = nextPosPlayer[1];
     board[i][j] = numPlayer;
}

int checkForWallCollision(int nbLin, int nbCol, int nextPosPlayer[]){
     if (nextPosPlayer[0] == nbLin - 1 || nextPosPlayer[0] == 0){
          return 1;
     }
     else if (nextPosPlayer[1] == nbCol - 1 || nextPosPlayer[1] == 0){
          return 1;
     }
     else {
          return 0;
     }
}

int checkForBeamCollision(int **board, int nextPosPlayer[]){
     int i, j;
     i = nextPosPlayer[0];
     j = nextPosPlayer[1];
     if (board[i][j] == 1 || board[i][j] == 2){
          return 1;
     }
     else {
          return 0;
     }
}

int runAStep(int nbLin, int nbCol, int **board, int vectPlayer1[], int vectPlayer2[]){
     int nextPosPlayer1[2];
     int nextPosPlayer2[2];

     int checkWallPlayer1 = 0;
     int checkWallPlayer2 = 0;

     int checkBeamPlayer1 = 0;
     int checkBeamPlayer2 = 0;

     catchNextEvents(vectPlayer1, vectPlayer2);
     calculateNextPosition(vectPlayer1, nextPosPlayer1);
     calculateNextPosition(vectPlayer2, nextPosPlayer2);

     checkWallPlayer1 = checkForWallCollision(nbLin, nbCol, nextPosPlayer1);
     checkWallPlayer2 = checkForWallCollision(nbLin, nbCol, nextPosPlayer2);

     checkBeamPlayer1 = checkForBeamCollision(board, nextPosPlayer1);
     checkBeamPlayer2 = checkForBeamCollision(board, nextPosPlayer2);

     int yPlayer1 = nextPosPlayer1[0];
     int xPlayer1 = nextPosPlayer1[1];

     int yPlayer2 = nextPosPlayer2[0];
     int xPlayer2 = nextPosPlayer2[1];

     if (checkWallPlayer1 == 1 || checkBeamPlayer1 == 1){
          board[yPlayer1][xPlayer1] = -1;
          return 2;
     }
     if (checkWallPlayer2 == 1 || checkBeamPlayer2 == 1){
          board[yPlayer2][xPlayer2] = -1;
          return 1;
     }

     if (xPlayer1 == xPlayer2 && yPlayer1 == yPlayer2){
          board[yPlayer1][xPlayer1] = -1;
          return 0;
     }

     if (board[yPlayer1][xPlayer1] != -1){
          moveVehicule(board, 1, vectPlayer1, nextPosPlayer1);
     }
     if (board[yPlayer2][xPlayer2] != -1){
          moveVehicule(board, 2, vectPlayer2, nextPosPlayer2);
     }

     vectPlayer1[0] = nextPosPlayer1[0];
     vectPlayer1[1] = nextPosPlayer1[1];

     vectPlayer2[0] = nextPosPlayer2[0];
     vectPlayer2[1] = nextPosPlayer2[1];

     return -1;
}

int runGame(int nbLin, int nbCol, int **board){
     int vectPlayer1[3]; //0 : position vertical       1 : position horizontale      2 : direction
     int vectPlayer2[3];

     int flag = 1;
     int winner;
     initVectPlayer(nbLin, nbCol, board, vectPlayer1, 1);
     initVectPlayer(nbLin, nbCol, board, vectPlayer2, 2);
     showBoard(nbLin, nbCol, board);

      while (flag == 1){
           winner = runAStep(nbLin, nbCol, board, vectPlayer1, vectPlayer2);
           showBoard(nbLin, nbCol, board);
           if (winner != -1){
                flag = 0;
           }
      }

     return winner;
}

void endOfGame(int numWinner){
     printf("\n\n#### THE GAME IS OVER ####\n");
     if (numWinner == 0) printf("\nIt's a draw!\n");
     else {
          printf("\nAnd the winner is Player %d!\n", numWinner);
     }
}

int main(int argc, char **argv){
     // int NBLIN = atoi(argv[1]);
     // int NBCOL = atoi(argv[2]);
     int **board;
     int winner;
     board = alloc_mat(NBLIN, NBCOL);
     initArray(NBLIN, NBCOL, 0, board);
     winner = runGame(NBLIN, NBCOL, board);
     endOfGame(winner);
     return 0;
}
